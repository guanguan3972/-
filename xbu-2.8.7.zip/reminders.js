// 定时提醒窗口逻辑
const listEl = document.getElementById('list');
const subEl = document.getElementById('sub');
const footEl = document.getElementById('foot');

let accountNames = {};

function parseDate(text) {
    // "YYYY-MM-DD HH:mm"
    const m = /(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/.exec(text || '');
    if (!m) return null;
    return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]);
}

function daysLeft(dt) {
    const now = new Date();
    const a = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const b = new Date(dt.getFullYear(), dt.getMonth(), dt.getDate());
    return Math.round((b - a) / 86400000);
}

function badgeFor(days) {
    if (days < 0) return { text: '已过', cls: '' };
    if (days === 0) return { text: '今天', cls: 'hot' };
    if (days <= 3) return { text: `还剩 ${days} 天`, cls: 'warn' };
    return { text: `还剩 ${days} 天`, cls: '' };
}

function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
    }[c]));
}

async function render() {
    let items = [];
    try { items = await window.reminderApi.getSchedule(); } catch (e) { items = []; }

    // 账号名
    try {
        const acc = await window.reminderApi.getAccounts();
        accountNames = (acc && acc.names) || {};
    } catch (e) { /* ignore */ }

    const rows = [];
    for (const it of items) {
        const dt = parseDate(it.last);
        if (!dt) continue;
        rows.push({ item: it, dt, days: daysLeft(dt) });
    }
    rows.sort((a, b) => a.dt - b.dt);

    if (footEl) {
        footEl.textContent = `共 ${rows.length} 条记录` + (window.__schedPath ? ` · ${window.__schedPath}` : '');
    }

    if (!rows.length) {
        listEl.innerHTML = '<div id="empty"><span class="big">⏰</span>还没有定时记录。<br>' +
            '用「启用定时发布」上传一批后，<br>这里会显示每本书最后一次发布的日期。</div>';
        subEl.textContent = '';
        return;
    }

    const soon = rows.filter(r => r.days >= 0 && r.days <= 3).length;
    subEl.textContent = `共 ${rows.length} 本` + (soon ? `，${soon} 本临近` : '');

    listEl.innerHTML = rows.map(({ item, days }) => {
        const badge = badgeFor(days);
        const cls = days < 0 ? '' : (days === 0 ? 'today' : (days <= 3 ? 'soon' : ''));
        const accName = accountNames[item.slot] || `账号 ${item.slot}`;
        return `<div class="item ${cls}">
            <span class="del" data-slot="${item.slot}" data-book="${escapeHtml(item.bookHash || '')}" title="移除这条记录">×</span>
            <div class="row1">
                <span class="book" title="${escapeHtml(item.bookName || item.bookHash || '')}">${escapeHtml(item.bookName || ('📕 ' + (item.bookHash || '')))}</span>
                <span class="acc">${escapeHtml(accName)}</span>
            </div>
            <div class="row2">
                <span class="date">${escapeHtml(item.last)}</span>
                <span class="badge ${badge.cls}">${badge.text}</span>
            </div>
            <div class="meta">定时 ${item.count || 0} 章 · 记录于 ${new Date(item.updated || Date.now()).toLocaleString()}</div>
        </div>`;
    }).join('');

    listEl.querySelectorAll('.del').forEach(el => {
        el.addEventListener('click', async (ev) => {
            ev.stopPropagation();
            try {
                await window.reminderApi.removeSchedule(el.dataset.slot, el.dataset.book);
            } catch (e) { /* ignore */ }
            render();
        });
    });
}

document.getElementById('refresh').addEventListener('click', render);

window.reminderApi.onChanged(() => render());

render();
