// 小白星月自动上传助手 — 桌面版主进程（单窗口多账号）
const { app, BrowserWindow, ipcMain, Menu, shell, webContents, session, screen, dialog } = require('electron');
// 允许无用户交互的窗口播放提示音
app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const crypto = require('crypto');

/* ---------------- 目录 ---------------- */
// 程序目录只放程序；登录状态、日志、诊断文件统一放 AppData，
// 这样把整个程序文件夹压缩转发出去，也不会带走任何账号信息。
const APP_HOME = path.dirname(process.execPath);
const DATA_DIR = path.join(process.env.LOCALAPPDATA || app.getPath('appData'), 'XiaobaiUploader');

/* ---------------- 日志 ---------------- */
const LOG_PATH = path.join(DATA_DIR, 'startup.log');
function flog(msg) {
    try {
        fs.appendFileSync(LOG_PATH, `[${new Date().toISOString()}] ${msg}\n`);
    } catch (e) { /* ignore */ }
}
process.on('uncaughtException', (e) => flog('uncaught: ' + (e && e.stack ? e.stack : e)));
process.on('unhandledRejection', (e) => flog('unhandledRejection: ' + (e && e.stack ? e.stack : e)));
flog('boot start, electron=' + process.versions.electron + ' chrome=' + process.versions.chrome);

/* ---------------- 便携目录 ---------------- */
const PORTABLE_DATA = DATA_DIR;   // 兼容旧变量名

try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    app.setPath('userData', DATA_DIR);
} catch (e) {
    flog('数据目录初始化失败: ' + (e && e.message));
}

/* ---------------- 旧版数据迁移 ---------------- */
function copyDirSync(src, dst) {
    fs.mkdirSync(dst, { recursive: true });
    for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
        const s = path.join(src, entry.name);
        const d = path.join(dst, entry.name);
        if (entry.isDirectory()) copyDirSync(s, d);
        else {
            try { fs.copyFileSync(s, d); } catch (e) { /* 跳过被占用的文件 */ }
        }
    }
}

function migrateLegacyData() {
    const legacy = path.join(APP_HOME, 'userdata');
    const already = path.join(DATA_DIR, 'Partitions');

    if (fs.existsSync(legacy) && !fs.existsSync(already)) {
        try {
            copyDirSync(legacy, DATA_DIR);
            flog('已把旧 userdata 迁移到 ' + DATA_DIR);
        } catch (e) {
            flog('迁移旧数据失败: ' + (e && e.message));
        }
    }

    if (fs.existsSync(legacy)) {
        const migrated = fs.existsSync(path.join(DATA_DIR, 'Partitions'));
        if (migrated) {
            // 已经复制到 AppData，程序目录里这份就删掉，免得被一起打包
            try {
                fs.rmSync(legacy, { recursive: true, force: true });
                flog('已删除程序目录里的旧 userdata');
            } catch (e) {
                const bak = path.join(APP_HOME, 'userdata.已迁移可删除');
                try { fs.renameSync(legacy, bak); } catch (e2) { /* ignore */ }
                flog('删除失败，已改名为 userdata.已迁移可删除');
            }
        }
    }

    for (const name of ['startup.log', 'debug.log', 'dump-inputs.json', 'dump-publish.html', 'dump-timed.json']) {
        const p = path.join(APP_HOME, name);
        if (!fs.existsSync(p)) continue;
        try {
            fs.renameSync(p, path.join(DATA_DIR, name));
        } catch (e) {
            try { fs.rmSync(p, { force: true }); } catch (e2) { /* ignore */ }
        }
    }
}

try { migrateLegacyData(); } catch (e) { flog('migrate 异常: ' + (e && e.message)); }


/* ---------------- 上传脚本 ---------------- */
let AUTOMATION = '';
try {
    AUTOMATION = fs.readFileSync(path.join(__dirname, 'userscript.js'), 'utf8');
} catch (e) {
    flog('读取脚本失败: ' + e.message);
}

/* ---------------- 写文件（诊断用） ---------------- */
function safeWrite(name, text) {
    const dir = DATA_DIR;
    const base = path.basename(String(name)).replace(/[\\/:*?"<>|]/g, '_');
    try {
        fs.writeFileSync(path.join(dir, base), String(text), 'utf8');
        flog('已写入 ' + base + ' (' + String(text).length + ' 字节)');
    } catch (e) {
        flog('写入 ' + base + ' 失败: ' + (e && e.message));
    }
}


/* ---------------- 程序完整性校验（防篡改/防夹带） ---------------- */
const INTEGRITY_FILE = path.join(__dirname, 'integrity.json');
const INTEGRITY_PUBKEY = `-----BEGIN PUBLIC KEY-----
MCowBQYDK2VwAyEAK0yUwyqNHZgfkYa0AMvaKhnVFSiEfgyCAv1NBigXnJE=
-----END PUBLIC KEY-----`;

function verifyIntegrity() {
    let raw;
    try {
        raw = fs.readFileSync(INTEGRITY_FILE, 'utf8');
    } catch (e) {
        // 没有清单（开发版）就跳过
        return { ok: true, skipped: true };
    }

    let doc, payload, files;
    try {
        doc = JSON.parse(raw);
        payload = doc.payload;
        files = JSON.parse(doc.payload).files;
    } catch (e) {
        return { ok: false, reason: '清单损坏' };
    }

    // 1) 验签：确认清单是作者签发的
    let good = false;
    try {
        good = crypto.verify(null, Buffer.from(payload, 'utf8'), INTEGRITY_PUBKEY, Buffer.from(doc.sig, 'base64'));
    } catch (e) {
        good = false;
    }
    if (!good) return { ok: false, reason: '签名不匹配（不是官方签发）' };

    // 2) 逐个文件比对哈希
    const bad = [];
    for (const name of Object.keys(files)) {
        const full = path.join(__dirname, name);
        try {
            const h = crypto.createHash('sha256').update(fs.readFileSync(full)).digest('hex');
            if (h !== files[name]) bad.push(name);
        } catch (e) {
            bad.push(name + '（缺失）');
        }
    }

    // 3) 出现清单里没有的文件，也提示（可能是被塞进来的）
    const extra = [];
    try {
        for (const name of fs.readdirSync(__dirname)) {
            if (name === 'integrity.json') continue;
            const full = path.join(__dirname, name);
            if (!fs.statSync(full).isFile()) continue;
            if (!files[name]) extra.push(name);
        }
    } catch (e) { /* ignore */ }

    if (bad.length || extra.length) {
        return { ok: false, reason: '文件被改动', bad: bad, extra: extra };
    }
    return { ok: true, count: Object.keys(files).length };
}

/* ---------------- 账号列表（以磁盘 accounts.json 为准） ---------------- */
const ACCOUNTS_FILE = path.join(PORTABLE_DATA, 'accounts.json');

// 磁盘上真实存在的账号分区（fanqie-1、fanqie-2……）
function existingPartitionSlots() {
    const dir = path.join(PORTABLE_DATA, 'Partitions');
    const out = [];
    try {
        for (const name of fs.readdirSync(dir)) {
            const m = /^fanqie-(\d+)$/.exec(name);
            if (m) out.push(Number(m[1]));
        }
    } catch (e) { /* 首次运行没有该目录 */ }
    return out;
}

function readAccounts() {
    let stored = [];
    let last = 0;
    let rawNames = {};
    let closed = [];
    let openTabs = null;
    try {
        const a = JSON.parse(fs.readFileSync(ACCOUNTS_FILE, 'utf8'));
        stored = Array.isArray(a.slots) ? a.slots.filter(n => Number.isInteger(n) && n > 0) : [];
        last = Number(a.last) || 0;
        if (a.names && typeof a.names === 'object') rawNames = a.names;
        if (Array.isArray(a.closed)) closed = a.closed.filter(n => Number.isInteger(n));
        if (Array.isArray(a.openTabs)) openTabs = a.openTabs.filter(n => Number.isInteger(n) && n > 0);
    } catch (e) { /* 首次运行 */ }

    // 只认 accounts.json 里登记的账号；磁盘上残留的分区目录不再算作账号
    let slots = Array.from(new Set(stored)).sort((x, y) => x - y);

    // 自动剔除空槽位：既没有分区目录、也没有自定义名字、又不在当前打开列表里的，
    // 说明它没有实际数据（多为历史脏数据），直接丢掉
    const tabs = Array.isArray(openTabs) ? openTabs : [];
    const kept = slots.filter((s) => {
        if (tabs.includes(s)) return true;
        if (rawNames && rawNames[s]) return true;
        return fs.existsSync(path.join(DATA_DIR, 'Partitions', 'fanqie-' + s));
    });
    if (kept.length !== slots.length) {
        slots = kept;
        try {
            const fixed = { slots: slots, last: last, names: rawNames };
            if (Array.isArray(openTabs)) fixed.openTabs = openTabs.filter(s => slots.includes(s));
            fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(fixed, null, 2), 'utf8');
            flog('已自动清理 ' + (kept.length ? (stored.length - kept.length) : 0) + ' 个空账号槽位');
        } catch (e) { /* ignore */ }
    }

    if (!slots.length) slots = [1];
    if (!slots.includes(last)) last = slots[0];

    // 只保留当前存在的账号的名字
    const names = {};
    for (const s of slots) {
        const v = rawNames[s];
        if (v && String(v).trim()) names[s] = String(v).trim().slice(0, 20);
    }
    const closedSlots = closed.filter(s => slots.includes(s));
    const openList = (openTabs === null) ? null : openTabs.filter(s => slots.includes(s));
    return { slots, last, names, closed: closedSlots, openTabs: openList };
}

function writeAccounts(a) {
    try {
        fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(a, null, 2), 'utf8');
    } catch (e) {
        flog('写 accounts.json 失败: ' + (e && e.message));
    }
}



/* ---------------- 应用内更新 ---------------- */
let PKG_VERSION = '0.0.0';
try { PKG_VERSION = JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8')).version || '0.0.0'; } catch (e) { /* ignore */ }

const UPDATE_CFG = path.join(DATA_DIR, 'update.json');

// 默认更新源：按顺序尝试，前面的没有缓存、更可靠
const GH_OWNER = 'guanguan3972';
const GH_REPO = '-';
const GH_BRANCH = 'main';

const SOURCES_GH = [
    // 1) GitHub API：无 CDN 缓存，最及时
    'https://api.github.com/repos/' + GH_OWNER + '/' + GH_REPO + '/contents/update.json',
    // 2) raw：直连仓库内容
    'https://raw.githubusercontent.com/' + GH_OWNER + '/' + GH_REPO + '/' + GH_BRANCH + '/update.json',
    // 3) jsDelivr：国内较快，但有缓存
    'https://cdn.jsdelivr.net/gh/' + GH_OWNER + '/' + GH_REPO + '@' + GH_BRANCH + '/update.json'
];

const DEFAULT_FEED = SOURCES_GH[0];
const FALLBACK_FEED = SOURCES_GH[1];

function feedUrl() {
    const cfg = readUpdateCfg();
    return (cfg.feed && String(cfg.feed).trim()) || DEFAULT_FEED;
}

function readUpdateCfg() {
    try { return JSON.parse(fs.readFileSync(UPDATE_CFG, 'utf8')) || {}; } catch (e) { return {}; }
}
function writeUpdateCfg(o) {
    try { fs.writeFileSync(UPDATE_CFG, JSON.stringify(o, null, 2), 'utf8'); } catch (e) { /* ignore */ }
}
function cmpVersion(a, b) {
    const pa = String(a || '0').split('.').map(n => parseInt(n, 10) || 0);
    const pb = String(b || '0').split('.').map(n => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
        const x = pa[i] || 0, y = pb[i] || 0;
        if (x > y) return 1;
        if (x < y) return -1;
    }
    return 0;
}

let updaterWin = null;

function openUpdaterWindow() {
    if (updaterWin && !updaterWin.isDestroyed()) {
        updaterWin.show(); updaterWin.focus();
        return updaterWin;
    }
    updaterWin = new BrowserWindow({
        width: 460, height: 400, resizable: false,
        title: '检查更新', autoHideMenuBar: true,
        backgroundColor: '#f7f9fc',
        webPreferences: {
            preload: path.join(__dirname, 'updater-preload.js'),
            contextIsolation: false,
            nodeIntegration: false
        }
    });
    updaterWin.setMenuBarVisibility(false);
    updaterWin.loadFile(path.join(__dirname, 'updater.html'));
    updaterWin.on('closed', () => { updaterWin = null; });
    return updaterWin;
}

/* ---------------- 定时计划记录 ---------------- */
const SCHEDULE_FILE = path.join(DATA_DIR, 'schedule.json');

function bookHashOf(raw) {
    const s = String(raw || '');
    let h = 5381;
    for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
    return '#' + h.toString(16).padStart(8, '0').slice(0, 8);
}

// 只保留脱敏字段：不存书名、不存原始书号
function sanitizeRecord(rec) {
    if (!rec) return null;
    const hash = rec.bookHash || (rec.bookId ? bookHashOf(rec.bookId) : '');
    if (!hash) return null;
    return {
        slot: Number(rec.slot) || 0,
        bookHash: hash,
        bookName: String(rec.bookName || '').slice(0, 40),
        last: String(rec.last || ''),
        count: Number(rec.count) || 0,
        lastChapter: Number(rec.lastChapter) || 0,
        source: rec.source || 'manual',
        updated: Number(rec.updated) || Date.now()
    };
}

function readSchedule() {
    let raw = [];
    try {
        const arr = JSON.parse(fs.readFileSync(SCHEDULE_FILE, 'utf8'));
        raw = Array.isArray(arr) ? arr : [];
    } catch (e) {
        return [];
    }

    // 迁移旧格式：带 bookName / bookId 的记录一律脱敏并重写
    let dirty = false;
    const clean = [];
    for (const r of raw) {
        if (r.bookId !== undefined) dirty = true;
        const s = sanitizeRecord(r);
        if (s) clean.push(s);
    }
    if (dirty) {
        try {
            fs.writeFileSync(SCHEDULE_FILE, JSON.stringify(clean, null, 2), 'utf8');
            flog('已清除 schedule.json 里的书名等隐私字段');
        } catch (e) { /* ignore */ }
    }
    return clean;
}

function writeSchedule(list) {
    try {
        fs.writeFileSync(SCHEDULE_FILE, JSON.stringify(list, null, 2), 'utf8');
    } catch (e) {
        flog('写 schedule.json 失败: ' + (e && e.message));
    }
}

let reminderWin = null;

function notifyReminder() {
    if (reminderWin && !reminderWin.isDestroyed()) {
        try { reminderWin.webContents.send('schedule:changed'); } catch (e) { /* ignore */ }
    }
}

/* ---------------- IPC ---------------- */
// 每次注入都重新读文件，这样更新 userscript.js 后刷新页面即可生效，无需重启程序
ipcMain.handle('get-automation', () => {
    try {
        return fs.readFileSync(path.join(__dirname, 'userscript.js'), 'utf8');
    } catch (e) {
        flog('读取脚本失败（用内存副本）: ' + (e && e.message));
        return AUTOMATION;
    }
});


ipcMain.on('schedule:add', (event, text) => {
    let raw;
    try { raw = JSON.parse(String(text)); } catch (e) { return; }
    const rec = sanitizeRecord(raw);
    if (!rec) return;

    const list = readSchedule();
    const idx = list.findIndex(x => String(x.slot) === String(rec.slot) && x.bookHash === rec.bookHash);
    if (idx >= 0) {
        const old = list[idx];
        const merged = Object.assign({}, old, rec);
        // 扫描记录本身没有章数和章节号，不能把已有信息冲成 0
        if (!rec.count && old.count) merged.count = old.count;
        if (!rec.lastChapter && old.lastChapter) merged.lastChapter = old.lastChapter;
        if (!rec.bookName && old.bookName) merged.bookName = old.bookName;
        list[idx] = merged;
    } else {
        list.push(rec);
    }
    writeSchedule(list);
    notifyReminder();
    flog('记录定时计划: ' + rec.bookHash + ' -> ' + rec.last);
});


/* ---------------- 更新 IPC ---------------- */
ipcMain.handle('update:info', () => ({ current: PKG_VERSION, feed: feedUrl(), isDefault: !readUpdateCfg().feed }));

ipcMain.handle('update:set-feed', (event, url) => {
    const v = String(url || '').trim();
    const o = readUpdateCfg();

    // 空 = 恢复默认更新源
    if (!v) {
        delete o.feed;
        writeUpdateCfg(o);
        flog('已恢复默认更新源');
        return { ok: true, feed: feedUrl(), isDefault: true };
    }

    if (!/^https:\/\//i.test(v)) {
        return { ok: false, error: '地址要以 https:// 开头', feed: o.feed || '', isDefault: !o.feed };
    }
    if (!/\.json$/i.test(v)) {
        return { ok: false, error: '地址要以 .json 结尾（这是更新信息文件）', feed: o.feed || '', isDefault: !o.feed };
    }

    o.feed = v;
    writeUpdateCfg(o);
    flog('更新源已设置: ' + v);
    return { ok: true, feed: v, isDefault: false };
});

ipcMain.handle('update:check', async () => {
    const custom = readUpdateCfg().feed;
    const sources = custom ? [custom].concat(SOURCES_GH) : SOURCES_GH.slice();

    let lastErr = '';
    for (const feed of sources) {
        try {
            const url = feed + (feed.indexOf('?') >= 0 ? '&' : '?') + 't=' + Date.now();
            const res = await fetch(url, { cache: 'no-store' });
            if (!res.ok) { lastErr = '更新源暂时打不开（HTTP ' + res.status + '）'; continue; }
            let meta = await res.json();
            // GitHub API 会包一层 {content: base64, encoding: 'base64'}
            if (meta && meta.encoding === 'base64' && meta.content) {
                try {
                    const raw = Buffer.from(meta.content, 'base64').toString('utf8');
                    meta = JSON.parse(raw);
                } catch (e) { lastErr = '更新源内容解析失败'; continue; }
            }
            if (!meta || !meta.version) { lastErr = '更新源内容格式不对'; continue; }
            return {
                ok: true,
                current: PKG_VERSION,
                latest: meta.version,
                newer: cmpVersion(meta.version, PKG_VERSION) > 0,
                url: meta.url || '',
                sha256: meta.sha256 || '',
                notes: meta.notes || ''
            };
        } catch (e) {
            lastErr = '网络不通，请检查网络后重试';
        }
    }
    return { ok: false, reason: lastErr || '检查失败，请稍后重试' };
});

// 旧的解析逻辑保留在下方（不会被调用）
async function legacyCheck(feed) {
    try {
        const url = feed + (feed.indexOf('?') >= 0 ? '&' : '?') + 't=' + Date.now();
        const res = await fetch(url, { cache: 'no-store' });
        if (!res.ok) return { ok: false, reason: 'HTTP ' + res.status };
        const meta = await res.json();
        if (!meta || !meta.version) return { ok: false, reason: '更新源格式不对' };
        return {
            ok: true,
            current: PKG_VERSION,
            latest: meta.version,
            newer: cmpVersion(meta.version, PKG_VERSION) > 0,
            url: meta.url || '',
            sha256: meta.sha256 || '',
            notes: meta.notes || ''
        };
    } catch (e) {
        return { ok: false, reason: (e && e.message) || '网络错误' };
    }
}

// 解压 + 替换 + 重启（在线更新和本地文件更新共用）
async function applyZipAndRestart(zipPath) {
    const dir = path.join(DATA_DIR, 'update');
    const outDir = path.join(dir, 'app');
    try { fs.rmSync(outDir, { recursive: true, force: true }); } catch (e) { /* ignore */ }

    const psCmd = `Expand-Archive -LiteralPath "${zipPath}" -DestinationPath "${outDir}" -Force`;
    await new Promise((resolve, reject) => {
        const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', psCmd], { windowsHide: true });
        p.on('exit', (code) => code === 0 ? resolve() : reject(new Error('解压失败 ' + code)));
        p.on('error', reject);
    });

    let appSrc = outDir;
    try {
        const items = fs.readdirSync(outDir);
        if (items.length === 1 && fs.statSync(path.join(outDir, items[0])).isDirectory()) {
            appSrc = path.join(outDir, items[0]);
        }
    } catch (e) { /* ignore */ }

    if (!fs.existsSync(path.join(appSrc, 'main.js'))) {
        return { ok: false, reason: '更新包不完整（缺少程序文件）' };
    }

    // 版本闸：只允许装比当前新的包，防止被旧包降级
    let packVer = '';
    try {
        packVer = JSON.parse(fs.readFileSync(path.join(appSrc, 'package.json'), 'utf8')).version || '';
    } catch (e) { /* ignore */ }
    if (packVer && cmpVersion(packVer, PKG_VERSION) <= 0) {
        return { ok: false, reason: '这个包是 v' + packVer + '，不比当前的 v' + PKG_VERSION + ' 新，已取消' };
    }

    const appDir = path.join(APP_HOME, 'resources', 'app');
    const exePath = process.execPath;
    const ps1Path = path.join(dir, 'apply.ps1');

    const q = (s) => '"' + s + '"';
    const ps = [
        'Start-Sleep -Seconds 3',
        // 等待旧进程真正退出（最多 12 秒），否则文件被占用会复制失败
        '$exe = ' + q(exePath),
        'for ($i = 0; $i -lt 24; $i++) {',
        '  $p = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq $exe }',
        '  if (-not $p) { break }',
        '  if ($i -eq 0) { $p | Stop-Process -Force -ErrorAction SilentlyContinue }',
        '  Start-Sleep -Milliseconds 500',
        '}',
        'Start-Sleep -Milliseconds 500',
        '$app=' + q(appDir),
        '$src=' + q(appSrc),
        'if (Test-Path -LiteralPath ($app + ".old")) { Remove-Item -LiteralPath ($app + ".old") -Recurse -Force -ErrorAction SilentlyContinue }',
        'Rename-Item -LiteralPath $app -NewName "app.old" -ErrorAction SilentlyContinue',
        'try {',
        '  New-Item -ItemType Directory -Force -Path $app | Out-Null',
        '  Copy-Item -Path ($src + "\\*") -Destination $app -Recurse -Force -ErrorAction Stop',
        '  if (-not (Test-Path -LiteralPath ($app + "\\main.js"))) { throw "copy incomplete" }',
        '} catch {',
        '  if (Test-Path -LiteralPath $app) { Remove-Item -LiteralPath $app -Recurse -Force -ErrorAction SilentlyContinue }',
        '  if (Test-Path -LiteralPath ($app + ".old")) { Rename-Item -LiteralPath ($app + ".old") -NewName "app" -ErrorAction SilentlyContinue }',
        '}',
        'for ($k = 0; $k -lt 3; $k++) { try { Start-Process -FilePath $exe -ErrorAction Stop; break } catch { Start-Sleep -Seconds 2 } }',
        'Start-Sleep -Seconds 2',
        'Remove-Item -LiteralPath ($app + ".old") -Recurse -Force -ErrorAction SilentlyContinue',
        'Remove-Item -LiteralPath $MyInvocation.MyCommand.Path -Force -ErrorAction SilentlyContinue'
    ];
    fs.writeFileSync(ps1Path, '\ufeff' + ps.join('\r\n') + '\r\n', 'utf8');
    flog('更新包已解压，准备替换');

    const child = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ps1Path],
        { detached: true, stdio: 'ignore', windowsHide: true });
    child.unref();

    setTimeout(() => app.quit(), 400);
    return { ok: true };
}

function sendProgress(p) {
    for (const w of BrowserWindow.getAllWindows()) {
        try { w.webContents.send('update:progress', p); } catch (e) { /* ignore */ }
    }
}

ipcMain.handle('update:apply', async (event, meta) => {
    try {
        if (!meta || !meta.url) return { ok: false, reason: '缺少下载地址' };

        const dir = path.join(DATA_DIR, 'update');
        try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) { /* ignore */ }
        fs.mkdirSync(dir, { recursive: true });

        const zipPath = path.join(dir, 'app.zip');
        // 多路下载：GitHub raw 在国内经常超时，逐个试镜像
        const rawUrl = String(meta.url || '');
        const zipUrls = [];
        const push = (u) => { if (u && !zipUrls.includes(u)) zipUrls.push(u); };

        // 从 raw 地址解析出 owner/repo/branch/文件
        let gh = null;
        const mRaw = /^https:\/\/raw\.githubusercontent\.com\/([^/]+)\/([^/]+)\/([^/]+)\/(.+)$/.exec(rawUrl);
        const mCdn = /^https:\/\/cdn\.jsdelivr\.net\/gh\/([^/]+)\/([^@]+)@([^/]+)\/(.+)$/.exec(rawUrl);
        if (mRaw) gh = { owner: mRaw[1], repo: mRaw[2], branch: mRaw[3], file: mRaw[4] };
        else if (mCdn) gh = { owner: mCdn[1], repo: mCdn[2], branch: mCdn[3], file: mCdn[4] };

        let rawRef = '';
        if (gh) {
            rawRef = `https://raw.githubusercontent.com/${gh.owner}/${gh.repo}/${gh.branch}/${gh.file}`;
            // 实测：raw 在国内常超时，所以先走 jsDelivr 和加速镜像
            push(`https://cdn.jsdelivr.net/gh/${gh.owner}/${gh.repo}@${gh.branch}/${gh.file}`);
            push('https://ghfast.top/' + rawRef);
            push('https://gh-proxy.com/' + rawRef);
            push('https://ghproxy.net/' + rawRef);
            push(rawRef); // 最后才试直连
        } else {
            push(rawUrl);
        }

        const fetchWithTimeout = async (u, ms) => {
            const ctrl = new AbortController();
            const timer = setTimeout(() => ctrl.abort(), ms);
            try {
                return await fetch(u, { signal: ctrl.signal, headers: { 'User-Agent': 'xbu-updater' } });
            } finally {
                clearTimeout(timer);
            }
        };

        let buf = null;
        const errors = [];
        for (const u of zipUrls) {
            try {
                flog('尝试下载: ' + u);
                sendProgress({ phase: 'download', percent: 0, text: '正在连接下载服务器…' });
                const res = await fetchWithTimeout(u, 12000);
                if (!res.ok) { errors.push('HTTP ' + res.status); continue; }

                const total = Number(res.headers.get('content-length')) || Number(meta.size) || 0;
                const reader = res.body.getReader();
                const chunks = [];
                let received = 0;
                let lastTick = 0;

                while (true) {
                    const { done, value } = await reader.read();
                    if (done) break;
                    chunks.push(value);
                    received += value.length;
                    const now = Date.now();
                    if (now - lastTick > 120) {
                        lastTick = now;
                        const percent = total ? Math.min(99, Math.round(received * 100 / total)) : 0;
                        sendProgress({
                            phase: 'download',
                            percent: percent,
                            received: received,
                            total: total,
                            text: '正在下载更新包 ' + Math.round(received / 1024) + ' KB' + (total ? ' / ' + Math.round(total / 1024) + ' KB' : '')
                        });
                    }
                }

                buf = Buffer.concat(chunks.map(c => Buffer.from(c)));
                if (buf.length < 1000) { buf = null; errors.push('内容过小'); continue; }
                sendProgress({ phase: 'download', percent: 100, text: '下载完成' });
                flog('下载成功: ' + u + '（' + buf.length + ' 字节）');
                break;
            } catch (e) {
                errors.push('超时/连接失败');
            }
        }

        // 所有直连都失败时，用 GitHub 内容接口（base64）再试一次
        if (!buf && gh) {
            try {
                const api = `https://api.github.com/repos/${gh.owner}/${gh.repo}/contents/${gh.file}?ref=${gh.branch}`;
                flog('改用 GitHub 内容接口: ' + api);
                const res = await fetchWithTimeout(api, 25000);
                if (res.ok) {
                    const j = await res.json();
                    if (j && j.encoding === 'base64' && j.content) {
                        sendProgress({ phase: 'download', percent: 60, text: '通过 GitHub 接口下载中…' });
                        buf = Buffer.from(j.content, 'base64');
                        sendProgress({ phase: 'download', percent: 100, text: '下载完成' });
                        flog('内容接口下载成功（' + buf.length + ' 字节）');
                    }
                }
            } catch (e) { /* ignore */ }
        }

        if (!buf) {
            return { ok: false, reason: '下载更新包失败：网络连不上 GitHub（已试 ' + zipUrls.length + ' 个地址），请换个网络或稍后重试，也可以用安装包更新' };
        }
        if (!buf) return { ok: false, reason: '下载更新包失败：' + dlErr };
        fs.writeFileSync(zipPath, buf);

        if (meta.sha256) {
            const h = crypto.createHash('sha256').update(buf).digest('hex');
            if (h.toLowerCase() !== String(meta.sha256).toLowerCase()) {
                return { ok: false, reason: '更新包校验失败（文件可能没传完）' };
            }
        }
        sendProgress({ phase: 'apply', percent: 0, text: '正在解压更新包…' });
        const applied = await applyZipAndRestart(zipPath);
        if (applied && applied.ok) sendProgress({ phase: 'apply', percent: 100, text: '正在替换程序文件，即将重启…' });
        return applied;
    } catch (e) {
        flog('update 失败: ' + (e && e.stack ? e.stack : e));
        return { ok: false, reason: '更新出错，请重试；若一直失败请用安装包重装' };
    }
});

// 从本地 zip 更新（作者直接把包发给朋友，不需要任何网站）
ipcMain.handle('update:apply-file', async () => {
    try {
        const r = await dialog.showOpenDialog({
            title: '选择更新包（xbu-x.x.x.zip）',
            filters: [{ name: '更新包', extensions: ['zip'] }],
            properties: ['openFile']
        });
        if (r.canceled || !r.filePaths.length) return { ok: false, reason: 'cancelled' };

        flog('本地更新包: ' + r.filePaths[0]);
        return await applyZipAndRestart(r.filePaths[0]);
    } catch (e) {
        flog('本地更新失败: ' + (e && e.stack ? e.stack : e));
        return { ok: false, reason: '更新出错，请重试；若一直失败请用安装包重装' };
    }
});

ipcMain.handle('updater:open', () => { openUpdaterWindow(); return true; });

ipcMain.on('xbu:report', (event, name, data) => {
    try {
        const dir = path.join(DATA_DIR, 'reports');
        fs.mkdirSync(dir, { recursive: true });
        const file = path.join(dir, name + '-' + Date.now() + '.json');
        fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
        flog('诊断已保存: ' + file);
    } catch (e) {
        flog('诊断保存失败: ' + (e && e.message));
    }
});

/* ---------------- 设置 ---------------- */
const SETTINGS_FILE = path.join(DATA_DIR, 'settings.json');

function readSettings() {
    try { return JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8')) || {}; } catch (e) { return {}; }
}
function writeSettings(o) {
    try { fs.writeFileSync(SETTINGS_FILE, JSON.stringify(o, null, 2), 'utf8'); } catch (e) { /* ignore */ }
}

ipcMain.handle('settings:get', () => Object.assign({ dark: false, privacy: false, zoom: 1, bgRender: true, tileView: false }, readSettings()));

ipcMain.handle('settings:set', (event, patch) => {
    const s = Object.assign({ dark: false, privacy: false, zoom: 1, bgRender: true, tileView: false }, readSettings(), patch || {});
    writeSettings(s);
    for (const w of BrowserWindow.getAllWindows()) {
        try { w.webContents.send('settings:changed', s); } catch (e) { /* ignore */ }
    }
    return s;
});

let earningsWin = null;

function openEarningsWindow() {
    if (earningsWin && !earningsWin.isDestroyed()) { earningsWin.show(); earningsWin.focus(); return earningsWin; }
    earningsWin = new BrowserWindow({
        width: 420, height: 480, resizable: false,
        title: '收益', autoHideMenuBar: true,
        backgroundColor: '#f7f9fc',
        webPreferences: {
            preload: path.join(__dirname, 'earnings-preload.js'),
            contextIsolation: false,
            nodeIntegration: false
        }
    });
    earningsWin.setMenuBarVisibility(false);
    earningsWin.loadFile(path.join(__dirname, 'earnings.html'));
    earningsWin.on('closed', () => { earningsWin = null; });
    return earningsWin;
}

ipcMain.handle('earnings:open', () => { openEarningsWindow(); return true; });

let settingsWin = null;

function openSettingsWindow() {
    if (settingsWin && !settingsWin.isDestroyed()) { settingsWin.show(); settingsWin.focus(); return settingsWin; }
    settingsWin = new BrowserWindow({
        width: 460, height: 560, resizable: false,
        title: '设置', autoHideMenuBar: true,
        backgroundColor: '#f7f9fc',
        webPreferences: {
            preload: path.join(__dirname, 'settings-preload.js'),
            contextIsolation: false,
            nodeIntegration: false
        }
    });
    settingsWin.setMenuBarVisibility(false);
    settingsWin.loadFile(path.join(__dirname, 'settings.html'));
    settingsWin.on('closed', () => { settingsWin = null; });
    return settingsWin;
}

ipcMain.handle('settings:open', () => { openSettingsWindow(); return true; });

// 新建账号前清空该槽位的登录数据（复用被删掉的编号时保证是干净的）
ipcMain.handle('accounts:reset-slot', async (event, rawSlot) => {
    const slot = Number(rawSlot);
    try {
        await session.fromPartition('persist:fanqie-' + slot).clearStorageData();
        flog('已清空账号 ' + slot + ' 的槽位数据');
        return { ok: true };
    } catch (e) {
        flog('清空槽位失败: ' + (e && e.message));
        return { ok: false };
    }
});

ipcMain.on('splash:close', () => closeSplash());
ipcMain.on('splash:open-update', () => { closeSplash(); openUpdaterWindow(); });
ipcMain.handle('splash:open', () => { createSplash(); return true; });

/* ---------------- 已发章号（防重复上传） ---------------- */
const PROGRESS_FILE = path.join(DATA_DIR, 'progress.json');

function readProgress() {
    try {
        const o = JSON.parse(fs.readFileSync(PROGRESS_FILE, 'utf8'));
        return (o && typeof o === 'object') ? o : {};
    } catch (e) { return {}; }
}
function writeProgress(o) {
    try { fs.writeFileSync(PROGRESS_FILE, JSON.stringify(o, null, 2), 'utf8'); } catch (e) { /* ignore */ }
}

ipcMain.handle('progress:get', (event, bookHash) => {
    const o = readProgress();
    return o[String(bookHash)] || { max: 0, nums: [] };
});

ipcMain.handle('progress:set', (event, bookHash, num) => {
    const key = String(bookHash || '');
    const n = Number(num) || 0;
    if (!key || !n) return { max: 0, nums: [] };

    const o = readProgress();
    const rec = o[key] || { max: 0, nums: [] };
    rec.max = Math.max(rec.max || 0, n);
    const set = new Set(Array.isArray(rec.nums) ? rec.nums : []);
    set.add(n);
    rec.nums = [...set].sort((a, b) => a - b).slice(-500); // 只留最近 500 条
    rec.updated = Date.now();
    o[key] = rec;
    writeProgress(o);
    return rec;
});

/* ---------------- 每日统计 ---------------- */
const STATS_FILE = path.join(DATA_DIR, 'stats.json');

function todayKey() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
}

function readStats() {
    try {
        const o = JSON.parse(fs.readFileSync(STATS_FILE, 'utf8'));
        return (o && typeof o === 'object') ? o : {};
    } catch (e) { return {}; }
}

ipcMain.on('stats:add', (event, bookHash, chapters, words) => {
    try {
        const all = readStats();
        const key = todayKey();
        const day = all[key] || { chapters: 0, words: 0, books: [] };
        day.chapters += Number(chapters) || 0;
        day.words += Number(words) || 0;
        const bh = String(bookHash || '');
        if (bh && !day.books.includes(bh)) day.books.push(bh);
        all[key] = day;

        // 只保留最近 60 天
        const keys = Object.keys(all).sort();
        while (keys.length > 60) delete all[keys.shift()];

        fs.writeFileSync(STATS_FILE, JSON.stringify(all, null, 2), 'utf8');
        flog('今日统计: ' + day.chapters + ' 章 / ' + day.words + ' 字 / ' + day.books.length + ' 本');
    } catch (e) { /* ignore */ }
});

ipcMain.on('stats:income', (event, slot, bookHash, amount) => {
    try {
        const all = readStats();
        const key = todayKey();
        const day = all[key] || { chapters: 0, words: 0, books: [], income: 0, incomes: {} };
        if (!day.incomes) day.incomes = {};
        if (day.incomeDone) return;
        const s = String(slot || 0) + '|' + String(bookHash || ('t' + Date.now()));
        day.incomes[s] = Number(amount) || 0;
        // 总和 = 各账号相加
        // 只认新格式（slot:book<数字> 或 slot:acct），丢弃历史脏 key
        const clean = {};
        Object.keys(day.incomes).forEach((k) => {
            if (String(k).indexOf('|') > 0) clean[k] = day.incomes[k];
        });
        day.incomes = clean;
        day.income = Object.keys(clean).reduce((sum, k) => sum + (Number(clean[k]) || 0), 0);
        day.incomeAt = Date.now();
        all[key] = day;
        fs.writeFileSync(STATS_FILE, JSON.stringify(all, null, 2), 'utf8');
        flog('今日收益已记录: ¥' + day.income);
    } catch (e) { /* ignore */ }
});

ipcMain.handle('earnings:get', () => {
    const all = readStats();
    const keys = Object.keys(all).sort().slice(-7);
    const days = keys.map(k => ({
        date: k,
        chapters: all[k].chapters || 0,
        words: all[k].words || 0,
        books: (all[k].books || []).length,
        income: all[k].income || 0
    }));
    const today = all[todayKey()] || {};
    return {
        date: todayKey(),
        today: {
            chapters: today.chapters || 0,
            words: today.words || 0,
            books: (today.books || []).length,
            income: today.income || 0,
            incomes: today.incomes || {}
        },
        days: days
    };
});

ipcMain.handle('earnings:finish', (event, amount) => {
    const all = readStats();
    const k = todayKey();
    const day = all[k] || { chapters: 0, words: 0, books: [], income: 0, incomes: {} };
    const v = Number(amount);
    if (isFinite(v) && v >= 0) {
        day.incomes = { '0|nm:完成' : v };
        day.income = v;
    }
    day.incomeDone = true;
    day.incomeAt = Date.now();
    all[k] = day;
    try { fs.writeFileSync(STATS_FILE, JSON.stringify(all, null, 2), 'utf8'); } catch (e) { /* ignore */ }
    flog('今日收益已完成: ¥' + day.income);
    return { ok: true };
});

ipcMain.handle('earnings:unfinish', () => {
    const all = readStats();
    const k = todayKey();
    if (all[k]) { delete all[k].incomeDone; try { fs.writeFileSync(STATS_FILE, JSON.stringify(all, null, 2), 'utf8'); } catch (e) { /* ignore */ } }
    return { ok: true };
});

ipcMain.handle('earnings:add', (event, name, amount) => {
    const all = readStats();
    const k = todayKey();
    const day = all[k] || { chapters: 0, words: 0, books: [], income: 0, incomes: {} };
    if (!day.incomes) day.incomes = {};
    const label = String(name || '').trim() || ('自定义' + (Object.keys(day.incomes).length + 1));
    day.incomes['0|nm:' + label] = Number(amount) || 0;
    day.income = Object.keys(day.incomes).reduce((s, x) => s + (Number(day.incomes[x]) || 0), 0);
    try { fs.writeFileSync(STATS_FILE, JSON.stringify(all, null, 2), 'utf8'); } catch (e) { /* ignore */ }
    return { ok: true };
});

ipcMain.handle('earnings:delete', (event, key) => {
    const all = readStats();
    const k = todayKey();
    const day = all[k];
    if (day && day.incomes && day.incomes[key] !== undefined) {
        delete day.incomes[key];
        day.income = Object.keys(day.incomes).reduce((s, x) => s + (Number(day.incomes[x]) || 0), 0);
        try { fs.writeFileSync(STATS_FILE, JSON.stringify(all, null, 2), 'utf8'); } catch (e) { /* ignore */ }
    }
    return { ok: true };
});

ipcMain.handle('earnings:clear', () => {
    const all = readStats();
    const k = todayKey();
    if (all[k]) {
        all[k].incomes = {};
        all[k].income = 0;
        try { fs.writeFileSync(STATS_FILE, JSON.stringify(all, null, 2), 'utf8'); } catch (e) { /* ignore */ }
    }
    return { ok: true };
});

ipcMain.handle('earnings:set-income', (event, amount) => {
    const all = readStats();
    const key = todayKey();
    const day = all[key] || { chapters: 0, words: 0, books: [], income: 0 };
    day.income = Number(amount) || 0;
    day.incomeAt = Date.now();
    all[key] = day;
    try { fs.writeFileSync(STATS_FILE, JSON.stringify(all, null, 2), 'utf8'); } catch (e) { /* ignore */ }
    flog('手动设置今日收益: ¥' + day.income);
    return { ok: true, income: day.income };
});

ipcMain.handle('stats:today', () => {
    const all = readStats();
    const day = all[todayKey()] || { chapters: 0, words: 0, books: [] };
    return {
        date: todayKey(),
        chapters: day.chapters || 0,
        words: day.words || 0,
        books: (day.books || []).length,
        income: day.income || 0
    };
});

ipcMain.handle('schedule:find', (event, bookHash) => {
    const key = String(bookHash || '');
    const list = readSchedule();
    const rec = list.find(x => x.bookHash === key);
    return rec || null;
});

ipcMain.handle('schedule:get', () => readSchedule());

ipcMain.handle('schedule:rename', (event, slot, bookHash, name) => {
    const list = readSchedule();
    const target = String(bookHash || '');
    const idx = list.findIndex(x => String(x.slot) === String(slot) && x.bookHash === target);
    if (idx >= 0) {
        list[idx].bookName = String(name || '').trim().slice(0, 40);
        writeSchedule(list);
        notifyReminder();
    }
    return list;
});

ipcMain.handle('schedule:remove', (event, slot, bookHash) => {
    const list = readSchedule().filter(x => !(String(x.slot) === String(slot) && x.bookHash === String(bookHash)));
    writeSchedule(list);
    notifyReminder();
    return list;
});


ipcMain.on('toast:close', () => closeToast());
ipcMain.on('toast:open-reminders', () => {
    closeToast();
    openReminderWindow();
});

ipcMain.handle('reminders:open', () => {
    openReminderWindow();
    return true;
});

ipcMain.handle('accounts:get', () => {
    const a = readAccounts();
    if (!fs.existsSync(ACCOUNTS_FILE)) writeAccounts(a);   // 首次运行就把合并结果落盘
    return a;
});

ipcMain.handle('accounts:add', (event, rawSlot) => {
    const slot = Number(rawSlot);
    const a = readAccounts();
    if (Number.isInteger(slot) && slot > 0 && !a.slots.includes(slot)) {
        a.slots.push(slot);
        a.slots.sort((x, y) => x - y);
    }
    a.last = slot;
    writeAccounts(a);
    flog('accounts:add ' + slot + ' -> ' + JSON.stringify(a));
    return a;
});

ipcMain.handle('accounts:remove', async (event, rawSlot) => {
    const slot = Number(rawSlot);
    const a = readAccounts();
    a.slots = a.slots.filter(s => s !== slot);
    if (!a.slots.length) a.slots = [1];
    if (!a.slots.includes(a.last)) a.last = a.slots[0];
    if (Array.isArray(a.openTabs)) a.openTabs = a.openTabs.filter(s => s !== slot);
    if (Array.isArray(a.closed)) a.closed = a.closed.filter(s => s !== slot);
    writeAccounts(a);

    try {
        await session.fromPartition(`persist:fanqie-${slot}`).clearStorageData();
        flog('已清除账号 ' + slot + ' 的登录数据');
    } catch (e) {
        flog('clearStorageData 失败: ' + (e && e.message));
    }

    // 顺手把磁盘上的分区目录也删掉，避免下次又被扫出来
    const pd = path.join(DATA_DIR, 'Partitions', 'fanqie-' + slot);
    try {
        fs.rmSync(pd, { recursive: true, force: true });
        flog('已删除分区目录 fanqie-' + slot);
    } catch (e) {
        // 正被占用，记下来下次启动再删
        const c = readCleanup();
        if (!c.includes(slot)) { c.push(slot); writeCleanup(c); }
        flog('分区目录被占用，已排队删除: fanqie-' + slot);
    }
    return a;
});

/* ---------------- 待清理的分区 ---------------- */
const CLEANUP_FILE = path.join(DATA_DIR, 'cleanup.json');

function readCleanup() {
    try {
        const arr = JSON.parse(fs.readFileSync(CLEANUP_FILE, 'utf8'));
        return Array.isArray(arr) ? arr : [];
    } catch (e) { return []; }
}
function writeCleanup(arr) {
    try { fs.writeFileSync(CLEANUP_FILE, JSON.stringify(arr), 'utf8'); } catch (e) { /* ignore */ }
}

function runCleanup() {
    const list = readCleanup();
    if (!list.length) return;
    const keep = [];
    for (const slot of list) {
        const pd = path.join(DATA_DIR, 'Partitions', 'fanqie-' + slot);
        try {
            fs.rmSync(pd, { recursive: true, force: true });
            flog('清理残留分区 fanqie-' + slot);
        } catch (e) {
            keep.push(slot);
        }
    }
    writeCleanup(keep);
}

ipcMain.handle('accounts:set-open-tabs', (event, list) => {
    const a = readAccounts();
    const arr = Array.isArray(list) ? list.filter(n => Number.isInteger(n) && n > 0) : [];
    a.openTabs = Array.from(new Set(arr)).sort((x, y) => x - y);
    writeAccounts(a);
    return a;
});

ipcMain.handle('accounts:set-open', (event, rawSlot, open) => {
    const slot = Number(rawSlot);
    const a = readAccounts();
    const closed = new Set(a.closed || []);
    if (open) closed.delete(slot); else closed.add(slot);
    a.closed = Array.from(closed).sort((x, y) => x - y);
    writeAccounts(a);
    flog('accounts:set-open ' + slot + ' -> ' + (open ? 'open' : 'closed'));
    return a;
});

ipcMain.handle('accounts:rename', (event, rawSlot, rawName) => {
    const slot = Number(rawSlot);
    const a = readAccounts();
    const name = String(rawName || '').trim().slice(0, 20);
    if (!a.names) a.names = {};
    if (name) a.names[slot] = name;
    else delete a.names[slot];
    writeAccounts(a);
    flog('accounts:rename ' + slot + ' -> "' + name + '"');
    return a;
});

ipcMain.on('accounts:set-last', (event, rawSlot) => {
    const slot = Number(rawSlot);
    const a = readAccounts();
    if (a.slots.includes(slot) && a.last !== slot) {
        a.last = slot;
        writeAccounts(a);
    }
});

ipcMain.on('save-file', (event, name, text) => safeWrite(name, text));

// 页面脚本（webview 内）通过 preload 发来的定时诊断
ipcMain.on('save-dump', (event, text) => safeWrite('dump-timed.json', text));

ipcMain.on('toggle-devtools', (event, id) => {
    try {
        const wc = webContents.fromId(Number(id));
        if (!wc) return;
        if (wc.isDevToolsOpened()) wc.closeDevTools();
        else wc.openDevTools({ mode: 'detach' });
    } catch (e) {
        flog('toggle-devtools failed: ' + (e && e.message));
    }
});


/* ---------------- 定时提醒窗口 ---------------- */
function openReminderWindow() {
    if (reminderWin && !reminderWin.isDestroyed()) {
        if (reminderWin.isMinimized()) reminderWin.restore();
        reminderWin.show();
        reminderWin.focus();
        try { reminderWin.webContents.send('schedule:changed'); } catch (e) { /* ignore */ }
        return reminderWin;
    }

    reminderWin = new BrowserWindow({
        width: 460,
        height: 480,
        minWidth: 380,
        minHeight: 280,
        title: '存稿 & 更新看板',
        alwaysOnTop: true,
        autoHideMenuBar: true,
        backgroundColor: '#f7f9fc',
        webPreferences: {
            preload: path.join(__dirname, 'reminder-preload.js'),
            contextIsolation: false,
            nodeIntegration: false
        }
    });

    reminderWin.setMenuBarVisibility(false);
    reminderWin.loadFile(path.join(__dirname, 'reminders.html'));
    reminderWin.webContents.on('did-finish-load', () => {
        try {
            reminderWin.webContents.executeJavaScript('window.__schedPath = ' + JSON.stringify(SCHEDULE_FILE));
        } catch (e) { /* ignore */ }
    });
    reminderWin.on('closed', () => { reminderWin = null; });
    flog('打开定时提醒窗口');
    return reminderWin;
}


/* ---------------- 左上角到期提醒 ---------------- */
const NOTIFIED_FILE = path.join(DATA_DIR, 'notified.json');

function readNotified() {
    try { return JSON.parse(fs.readFileSync(NOTIFIED_FILE, 'utf8')) || {}; } catch (e) { return {}; }
}
function writeNotified(obj) {
    try { fs.writeFileSync(NOTIFIED_FILE, JSON.stringify(obj, null, 2), 'utf8'); } catch (e) { /* ignore */ }
}

function todayKey() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

let toastWin = null;

function closeToast() {
    if (toastWin && !toastWin.isDestroyed()) toastWin.close();
    toastWin = null;
}

function privacyOn() {
    try { return !!readSettings().privacy; } catch (e) { return false; }
}

function maskIfPrivacy(name) {
    return privacyOn() ? '📕 ★★★（隐私模式）' : name;
}

function showToast(items, title) {
    closeToast();

    const disp = screen.getPrimaryDisplay();
    const wa = disp.workArea;

    toastWin = new BrowserWindow({
        width: 330,
        height: Math.min(220, 92 + items.length * 22),
        x: wa.x + 16,
        y: wa.y + 16,
        frame: false,
        transparent: true,
        resizable: false,
        movable: true,
        skipTaskbar: true,
        alwaysOnTop: true,
        show: false,
        webPreferences: {
            preload: path.join(__dirname, 'toast-preload.js'),
            contextIsolation: false,
            nodeIntegration: false
        }
    });

    // 系统提示音兜底（3 声，间隔 200ms）
    try {
        shell.beep();
        setTimeout(() => { try { shell.beep(); } catch (e) { /* ignore */ } }, 200);
        setTimeout(() => { try { shell.beep(); } catch (e) { /* ignore */ } }, 400);
    } catch (e) { /* ignore */ }

    toastWin.setAlwaysOnTop(true, 'screen-saver');
    toastWin.loadFile(path.join(__dirname, 'toast.html'));
    toastWin.once('ready-to-show', () => {
        toastWin.showInactive();
        const acc = readAccounts();
        const payload = {
            title: title,
            items: items.map(it => ({
                bookName: maskIfPrivacy(it.bookName || it.bookHash),
                last: it.last,
                days: (typeof it.days === 'number') ? it.days : null,
                account: (acc.names && acc.names[it.slot]) || ('账号 ' + it.slot)
            }))
        };
        try {
            toastWin.webContents.executeJavaScript('renderToast(' + JSON.stringify(payload) + ')');
        } catch (e) { /* ignore */ }
        setTimeout(closeToast, 15000);
    });
    toastWin.on('closed', () => { toastWin = null; });
    flog('弹出到期提醒: ' + items.length + ' 本');
}

// 检查今天是否某本书的最后一个定时发布日
function checkDueReminders() {
    const list = readSchedule();
    if (!list.length) return;

    const today = todayKey();
    const notified = readNotified();
    const due = [];

    for (const it of list) {
        const m = /(\d{4})-(\d{2})-(\d{2})/.exec(it.last || '');
        if (!m) continue;
        const dateKey = m[1] + '-' + m[2] + '-' + m[3];
        if (dateKey !== today) continue;

        const key = it.slot + ':' + it.bookId + ':' + today;
        if (notified[key]) continue;
        due.push(it);
    }

    if (!due.length) return;

    for (const it of due) {
        notified[it.slot + ':' + it.bookId + ':' + today] = Date.now();
    }
    writeNotified(notified);

    showToast(due, due.length > 1 ? `今天有 ${due.length} 本书走到最后一章定时` : '今天是这本书最后的定时发布日');
}

// 启动时：把所有还没到期的书汇总弹一次
function startupSummary() {
    const list = readSchedule();
    if (!list.length) return;

    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const rows = [];

    for (const it of list) {
        const m = /(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2})/.exec(it.last || '');
        if (!m) continue;
        const dt = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]);
        const days = Math.round((new Date(dt.getFullYear(), dt.getMonth(), dt.getDate()).getTime() - todayStart) / 86400000);
        if (days < 0) continue;
        rows.push({
            bookName: it.bookName || it.bookHash,
            last: it.last,
            slot: it.slot,
            days: days
        });
    }

    if (!rows.length) return;
    rows.sort((a, b) => a.days - b.days);

    const soon = rows.filter(r => r.days <= 3).length;
    const title = rows.length === 1
        ? `《${rows[0].bookName}》还剩 ${rows[0].days} 天到期`
        : `还有 ${rows.length} 本书在定时发布中` + (soon ? `（${soon} 本临近）` : '');

    showToast(rows, title);
}

function startReminderWatcher() {
    setTimeout(() => { try { startupSummary(); } catch (e) { /* ignore */ } }, 4000);
    setInterval(() => { try { checkDueReminders(); } catch (e) { /* ignore */ } }, 30 * 60 * 1000);
}


/* ---------------- 启动动画 ---------------- */
let splashWin = null;

function readChangelog() {
    try {
        return JSON.parse(fs.readFileSync(path.join(__dirname, 'changelog.json'), 'utf8'));
    } catch (e) {
        return { entries: [] };
    }
}

function createSplash() {
    splashWin = new BrowserWindow({
        width: 620,
        height: 330,
        frame: false,
        transparent: true,
        resizable: false,
        show: true,
        center: true,
        skipTaskbar: true,
        alwaysOnTop: true,
        backgroundColor: '#00000000',
        webPreferences: {
            preload: path.join(__dirname, 'splash-preload.js'),
            contextIsolation: false,
            nodeIntegration: false
        }
    });

    splashWin.loadFile(path.join(__dirname, 'splash.html'));
    splashWin.webContents.on('did-finish-load', () => {
        try {
            splashWin.webContents.executeJavaScript(
                'renderSplash(' + JSON.stringify({ version: PKG_VERSION, changelog: readChangelog() }) + ')'
            );
        } catch (e) { /* ignore */ }
    });
    splashWin.on('closed', () => { splashWin = null; });
    return splashWin;
}

function closeSplash() {
    if (splashWin && !splashWin.isDestroyed()) {
        try { splashWin.close(); } catch (e) { /* ignore */ }
        splashWin = null;
    }
}

/* ---------------- 主窗口 ---------------- */
function createWindow() {
    const win = new BrowserWindow({
        width: 1440,
        height: 920,
        minWidth: 960,
        minHeight: 640,
        title: '阿日上传助手',
        backgroundColor: '#f0f2f5',
        autoHideMenuBar: true,
        webPreferences: {
            preload: path.join(__dirname, 'shell-preload.js'),
            webviewTag: true,
            contextIsolation: false,
            nodeIntegration: false,
            spellcheck: false
        }
    });

    win.setMenuBarVisibility(false);
    win.loadFile(path.join(__dirname, 'shell.html'));

    // webview 内的新窗口：站外给系统浏览器，站内就地打开（不再弹第二个窗口）
    win.webContents.on('did-attach-webview', (event, contents) => {
        contents.setWindowOpenHandler(({ url }) => {
            if (!/^https?:/i.test(url)) {
                return { action: 'deny' };
            }
            if (!/fanqienovel\.com/i.test(url)) {
                shell.openExternal(url);
                return { action: 'deny' };
            }
            // 番茄的「新建章节」等用 window.open，这里改为在当前标签页内跳转
            setImmediate(() => {
                try {
                    contents.loadURL(url);
                    flog('站内 popup 就地打开: ' + url);
                } catch (e) {
                    flog('popup 就地打开失败: ' + (e && e.message));
                }
            });
            return { action: 'deny' };
        });
        contents.on('page-title-updated', (e) => e.preventDefault());
        contents.on('render-process-gone', (e, details) => {
            flog('webview render-process-gone: ' + JSON.stringify(details));
        });
    });

    win.on('closed', () => flog('main window closed'));
    return win;
}

/* ---------------- 启动 ---------------- */
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
    app.quit();
} else {
    app.on('second-instance', () => {
        const all = BrowserWindow.getAllWindows();
        if (all.length) {
            const w = all[0];
            if (w.isMinimized()) w.restore();
            w.focus();
        }
    });

    app.whenReady().then(() => {
        // 菜单保持极简，账号切换都在顶部标签页
        Menu.setApplicationMenu(Menu.buildFromTemplate([
            {
                label: '视图',
                submenu: [
                    { label: '放大', role: 'zoomIn' },
                    { label: '缩小', role: 'zoomOut' },
                    { label: '重置缩放', role: 'resetZoom' }
                ]
            }
        ]));
        createSplash();
        const win = createWindow();
        win.webContents.once('did-finish-load', () => {
            setTimeout(closeSplash, 5200);
        });
        // 兜底：最多显示 8 秒
        setTimeout(closeSplash, 8000);
        startReminderWatcher();
    });

    app.on('window-all-closed', () => app.quit());
}

/* ---------------- 退出前把 Cookie / 存储刷到磁盘 ---------------- */
let quitting = false;
app.on('before-quit', (e) => {
    if (quitting) return;
    quitting = true;
    e.preventDefault();

    try {
        for (const slot of readAccounts().slots) {
            try {
                session.fromPartition(`persist:fanqie-${slot}`).flushStorageData();
            } catch (err) { /* ignore */ }
        }
        flog('退出前已刷新各账号存储');
    } catch (err) {
        flog('flush 失败: ' + (err && err.message));
    }

    setTimeout(() => {
        try { app.quit(); } catch (err) { /* ignore */ }
    }, 800);
});
