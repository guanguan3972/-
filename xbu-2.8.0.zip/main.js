// 小白星月自动上传助手 — 桌面版主进程（单窗口多账号）
const { app, BrowserWindow, ipcMain, Menu, shell, webContents, session, screen, dialog } = require('electron');
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');

/* ---------------- 目录 ---------------- */
// 程序目录只放程序；登录状态、日志、诊断文件统一放 AppData，
// 这样把整个程序文件夹压缩转发出去，也不会带走任何账号信息。
const APP_HOME = path.dirname(process.execPath);
const DATA_DIR = path.join(process.env.LOCALAPPDATA || app.getPath('appData'), 'XiaobaiUploader');

/* ---------------- 日志 ---------------- */
const LOG_PATH = path.join(DATA_DIR, 'startup.log');
function flog(msg) {
    try {
        fs.appendFileSync(LOG_PATH, `[${new Date().toISOString()}] ${msg}\n`);
    } catch (e) { /* ignore */ }
}
process.on('uncaughtException', (e) => flog('uncaught: ' + (e && e.stack ? e.stack : e)));
process.on('unhandledRejection', (e) => flog('unhandledRejection: ' + (e && e.stack ? e.stack : e)));
flog('boot start, electron=' + process.versions.electron + ' chrome=' + process.versions.chrome);

/* ---------------- 便携目录 ---------------- */
const PORTABLE_DATA = DATA_DIR;   // 兼容旧变量名

try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    app.setPath('userData', DATA_DIR);
} catch (e) {
    flog('数据目录初始化失败: ' + (e && e.message));
}

/* ---------------- 旧版数据迁移 ---------------- */
function copyDirSync(src, dst) {
    fs.mkdirSync(dst, { recursive: true });
    for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
        const s = path.join(src, entry.name);
        const d = path.join(dst, entry.name);
        if (entry.isDirectory()) copyDirSync(s, d);
        else {
            try { fs.copyFileSync(s, d); } catch (e) { /* 跳过被占用的文件 */ }
        }
    }
}

function migrateLegacyData() {
    const legacy = path.join(APP_HOME, 'userdata');
    const already = path.join(DATA_DIR, 'Partitions');

    if (fs.existsSync(legacy) && !fs.existsSync(already)) {
        try {
            copyDirSync(legacy, DATA_DIR);
            flog('已把旧 userdata 迁移到 ' + DATA_DIR);
        } catch (e) {
            flog('迁移旧数据失败: ' + (e && e.message));
        }
    }

    if (fs.existsSync(legacy)) {
        const migrated = fs.existsSync(path.join(DATA_DIR, 'Partitions'));
        if (migrated) {
            // 已经复制到 AppData，程序目录里这份就删掉，免得被一起打包
            try {
                fs.rmSync(legacy, { recursive: true, force: true });
                flog('已删除程序目录里的旧 userdata');
            } catch (e) {
                const bak = path.join(APP_HOME, 'userdata.已迁移可删除');
                try { fs.renameSync(legacy, bak); } catch (e2) { /* ignore */ }
                flog('删除失败，已改名为 userdata.已迁移可删除');
            }
        }
    }

    for (const name of ['startup.log', 'debug.log', 'dump-inputs.json', 'dump-publish.html', 'dump-timed.json']) {
        const p = path.join(APP_HOME, name);
        if (!fs.existsSync(p)) continue;
        try {
            fs.renameSync(p, path.join(DATA_DIR, name));
        } catch (e) {
            try { fs.rmSync(p, { force: true }); } catch (e2) { /* ignore */ }
        }
    }
}

try { migrateLegacyData(); } catch (e) { flog('migrate 异常: ' + (e && e.message)); }


/* ---------------- 上传脚本 ---------------- */
let AUTOMATION = '';
try {
    AUTOMATION = fs.readFileSync(path.join(__dirname, 'userscript.js'), 'utf8');
} catch (e) {
    flog('读取脚本失败: ' + e.message);
}

/* ---------------- 写文件（诊断用） ---------------- */
function safeWrite(name, text) {
    const dir = DATA_DIR;
    const base = path.basename(String(name)).replace(/[\\/:*?"<>|]/g, '_');
    try {
        fs.writeFileSync(path.join(dir, base), String(text), 'utf8');
        flog('已写入 ' + base + ' (' + String(text).length + ' 字节)');
    } catch (e) {
        flog('写入 ' + base + ' 失败: ' + (e && e.message));
    }
}

/* ---------------- 账号列表（以磁盘 accounts.json 为准） ---------------- */
const ACCOUNTS_FILE = path.join(PORTABLE_DATA, 'accounts.json');

// 磁盘上真实存在的账号分区（fanqie-1、fanqie-2……）
function existingPartitionSlots() {
    const dir = path.join(PORTABLE_DATA, 'Partitions');
    const out = [];
    try {
        for (const name of fs.readdirSync(dir)) {
            const m = /^fanqie-(\d+)$/.exec(name);
            if (m) out.push(Number(m[1]));
        }
    } catch (e) { /* 首次运行没有该目录 */ }
    return out;
}

function readAccounts() {
    let stored = [];
    let last = 0;
    let rawNames = {};
    let closed = [];
    let openTabs = null;
    try {
        const a = JSON.parse(fs.readFileSync(ACCOUNTS_FILE, 'utf8'));
        stored = Array.isArray(a.slots) ? a.slots.filter(n => Number.isInteger(n) && n > 0) : [];
        last = Number(a.last) || 0;
        if (a.names && typeof a.names === 'object') rawNames = a.names;
        if (Array.isArray(a.closed)) closed = a.closed.filter(n => Number.isInteger(n));
        if (Array.isArray(a.openTabs)) openTabs = a.openTabs.filter(n => Number.isInteger(n) && n > 0);
    } catch (e) { /* 首次运行 */ }

    // 合并「配置文件里记的」和「磁盘上真实存在的分区」，谁多听谁的
    let slots = Array.from(new Set([...stored, ...existingPartitionSlots()])).sort((x, y) => x - y);
    if (!slots.length) slots = [1];
    if (!slots.includes(last)) last = slots[0];

    // 只保留当前存在的账号的名字
    const names = {};
    for (const s of slots) {
        const v = rawNames[s];
        if (v && String(v).trim()) names[s] = String(v).trim().slice(0, 20);
    }
    const closedSlots = closed.filter(s => slots.includes(s));
    const tabs = (openTabs === null) ? null : openTabs.filter(s => slots.includes(s));
    return { slots, last, names, closed: closedSlots, openTabs: tabs };
}

function writeAccounts(a) {
    try {
        fs.writeFileSync(ACCOUNTS_FILE, JSON.stringify(a, null, 2), 'utf8');
    } catch (e) {
        flog('写 accounts.json 失败: ' + (e && e.message));
    }
}



/* ---------------- 应用内更新 ---------------- */
let PKG_VERSION = '0.0.0';
try { PKG_VERSION = JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8')).version || '0.0.0'; } catch (e) { /* ignore */ }

const UPDATE_CFG = path.join(DATA_DIR, 'update.json');

// 默认更新源（作者填好，用户不用管）
const DEFAULT_FEED = 'https://cdn.jsdelivr.net/gh/guanguan3972/-@main/update.json';
const FALLBACK_FEED = 'https://raw.githubusercontent.com/guanguan3972/-/main/update.json';

function feedUrl() {
    const cfg = readUpdateCfg();
    return (cfg.feed && String(cfg.feed).trim()) || DEFAULT_FEED;
}

function readUpdateCfg() {
    try { return JSON.parse(fs.readFileSync(UPDATE_CFG, 'utf8')) || {}; } catch (e) { return {}; }
}
function writeUpdateCfg(o) {
    try { fs.writeFileSync(UPDATE_CFG, JSON.stringify(o, null, 2), 'utf8'); } catch (e) { /* ignore */ }
}
function cmpVersion(a, b) {
    const pa = String(a || '0').split('.').map(n => parseInt(n, 10) || 0);
    const pb = String(b || '0').split('.').map(n => parseInt(n, 10) || 0);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
        const x = pa[i] || 0, y = pb[i] || 0;
        if (x > y) return 1;
        if (x < y) return -1;
    }
    return 0;
}

let updaterWin = null;

function openUpdaterWindow() {
    if (updaterWin && !updaterWin.isDestroyed()) {
        updaterWin.show(); updaterWin.focus();
        return updaterWin;
    }
    updaterWin = new BrowserWindow({
        width: 460, height: 400, resizable: false,
        title: '检查更新', autoHideMenuBar: true,
        backgroundColor: '#f7f9fc',
        webPreferences: {
            preload: path.join(__dirname, 'updater-preload.js'),
            contextIsolation: false,
            nodeIntegration: false
        }
    });
    updaterWin.setMenuBarVisibility(false);
    updaterWin.loadFile(path.join(__dirname, 'updater.html'));
    updaterWin.on('closed', () => { updaterWin = null; });
    return updaterWin;
}

/* ---------------- 定时计划记录 ---------------- */
const SCHEDULE_FILE = path.join(DATA_DIR, 'schedule.json');

function bookHashOf(raw) {
    const s = String(raw || '');
    let h = 5381;
    for (let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) >>> 0;
    return '#' + h.toString(16).padStart(8, '0').slice(0, 8);
}

// 只保留脱敏字段：不存书名、不存原始书号
function sanitizeRecord(rec) {
    if (!rec) return null;
    const hash = rec.bookHash || (rec.bookId ? bookHashOf(rec.bookId) : '');
    if (!hash) return null;
    return {
        slot: Number(rec.slot) || 0,
        bookHash: hash,
        bookName: String(rec.bookName || '').slice(0, 40),
        last: String(rec.last || ''),
        count: Number(rec.count) || 0,
        source: rec.source || 'manual',
        updated: Number(rec.updated) || Date.now()
    };
}

function readSchedule() {
    let raw = [];
    try {
        const arr = JSON.parse(fs.readFileSync(SCHEDULE_FILE, 'utf8'));
        raw = Array.isArray(arr) ? arr : [];
    } catch (e) {
        return [];
    }

    // 迁移旧格式：带 bookName / bookId 的记录一律脱敏并重写
    let dirty = false;
    const clean = [];
    for (const r of raw) {
        if (r.bookId !== undefined) dirty = true;
        const s = sanitizeRecord(r);
        if (s) clean.push(s);
    }
    if (dirty) {
        try {
            fs.writeFileSync(SCHEDULE_FILE, JSON.stringify(clean, null, 2), 'utf8');
            flog('已清除 schedule.json 里的书名等隐私字段');
        } catch (e) { /* ignore */ }
    }
    return clean;
}

function writeSchedule(list) {
    try {
        fs.writeFileSync(SCHEDULE_FILE, JSON.stringify(list, null, 2), 'utf8');
    } catch (e) {
        flog('写 schedule.json 失败: ' + (e && e.message));
    }
}

let reminderWin = null;

function notifyReminder() {
    if (reminderWin && !reminderWin.isDestroyed()) {
        try { reminderWin.webContents.send('schedule:changed'); } catch (e) { /* ignore */ }
    }
}

/* ---------------- IPC ---------------- */
// 每次注入都重新读文件，这样更新 userscript.js 后刷新页面即可生效，无需重启程序
ipcMain.handle('get-automation', () => {
    try {
        return fs.readFileSync(path.join(__dirname, 'userscript.js'), 'utf8');
    } catch (e) {
        flog('读取脚本失败（用内存副本）: ' + (e && e.message));
        return AUTOMATION;
    }
});


ipcMain.on('schedule:add', (event, text) => {
    let raw;
    try { raw = JSON.parse(String(text)); } catch (e) { return; }
    const rec = sanitizeRecord(raw);
    if (!rec) return;

    const list = readSchedule();
    const idx = list.findIndex(x => String(x.slot) === String(rec.slot) && x.bookHash === rec.bookHash);
    if (idx >= 0) list[idx] = Object.assign({}, list[idx], rec);
    else list.push(rec);
    writeSchedule(list);
    notifyReminder();
    flog('记录定时计划: ' + rec.bookHash + ' -> ' + rec.last);
});


/* ---------------- 更新 IPC ---------------- */
ipcMain.handle('update:info', () => ({ current: PKG_VERSION, feed: feedUrl(), isDefault: !readUpdateCfg().feed }));

ipcMain.handle('update:set-feed', (event, url) => {
    const o = readUpdateCfg();
    o.feed = String(url || '').trim();
    writeUpdateCfg(o);
    flog('更新源已设置: ' + o.feed);
    return o.feed;
});

ipcMain.handle('update:check', async () => {
    const sources = [feedUrl()];
    if (!readUpdateCfg().feed) sources.push(FALLBACK_FEED);

    let lastErr = '';
    for (const feed of sources) {
        try {
            const url = feed + (feed.indexOf('?') >= 0 ? '&' : '?') + 't=' + Date.now();
            const res = await fetch(url, { cache: 'no-store' });
            if (!res.ok) { lastErr = 'HTTP ' + res.status; continue; }
            const meta = await res.json();
            if (!meta || !meta.version) { lastErr = '更新源格式不对'; continue; }
            return {
                ok: true,
                current: PKG_VERSION,
                latest: meta.version,
                newer: cmpVersion(meta.version, PKG_VERSION) > 0,
                url: meta.url || '',
                sha256: meta.sha256 || '',
                notes: meta.notes || ''
            };
        } catch (e) {
            lastErr = (e && e.message) || '网络错误';
        }
    }
    return { ok: false, reason: lastErr || '网络错误' };
});

// 旧的解析逻辑保留在下方（不会被调用）
async function legacyCheck(feed) {
    try {
        const url = feed + (feed.indexOf('?') >= 0 ? '&' : '?') + 't=' + Date.now();
        const res = await fetch(url, { cache: 'no-store' });
        if (!res.ok) return { ok: false, reason: 'HTTP ' + res.status };
        const meta = await res.json();
        if (!meta || !meta.version) return { ok: false, reason: '更新源格式不对' };
        return {
            ok: true,
            current: PKG_VERSION,
            latest: meta.version,
            newer: cmpVersion(meta.version, PKG_VERSION) > 0,
            url: meta.url || '',
            sha256: meta.sha256 || '',
            notes: meta.notes || ''
        };
    } catch (e) {
        return { ok: false, reason: (e && e.message) || '网络错误' };
    }
}

// 解压 + 替换 + 重启（在线更新和本地文件更新共用）
async function applyZipAndRestart(zipPath) {
    const dir = path.join(DATA_DIR, 'update');
    const outDir = path.join(dir, 'app');
    try { fs.rmSync(outDir, { recursive: true, force: true }); } catch (e) { /* ignore */ }

    const psCmd = `Expand-Archive -LiteralPath "${zipPath}" -DestinationPath "${outDir}" -Force`;
    await new Promise((resolve, reject) => {
        const p = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', psCmd], { windowsHide: true });
        p.on('exit', (code) => code === 0 ? resolve() : reject(new Error('解压失败 ' + code)));
        p.on('error', reject);
    });

    let appSrc = outDir;
    try {
        const items = fs.readdirSync(outDir);
        if (items.length === 1 && fs.statSync(path.join(outDir, items[0])).isDirectory()) {
            appSrc = path.join(outDir, items[0]);
        }
    } catch (e) { /* ignore */ }

    if (!fs.existsSync(path.join(appSrc, 'main.js'))) {
        return { ok: false, reason: '更新包结构不对（缺 main.js）' };
    }

    const appDir = path.join(APP_HOME, 'resources', 'app');
    const exePath = process.execPath;
    const ps1Path = path.join(dir, 'apply.ps1');

    const ps = [
        'Start-Sleep -Seconds 3',
        'Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.Path -eq "' + exePath + '" } | Stop-Process -Force -ErrorAction SilentlyContinue',
        'Start-Sleep -Seconds 1',
        'if (Test-Path -LiteralPath "' + appDir + '.old") { Remove-Item -LiteralPath "' + appDir + '.old" -Recurse -Force -ErrorAction SilentlyContinue }',
        'Rename-Item -LiteralPath "' + appDir + '" -NewName "app.old" -ErrorAction SilentlyContinue',
        'Copy-Item -Path "' + appSrc + '\*" -Destination "' + appDir + '" -Recurse -Force',
        'Start-Process -FilePath "' + exePath + '"',
        'Start-Sleep -Seconds 2',
        'Remove-Item -LiteralPath "' + appDir + '.old" -Recurse -Force -ErrorAction SilentlyContinue',
        'Remove-Item -LiteralPath $MyInvocation.MyCommand.Path -Force -ErrorAction SilentlyContinue'
    ];
    fs.writeFileSync(ps1Path, '\ufeff' + ps.join('\r\n') + '\r\n', 'utf8');
    flog('更新包已解压，准备替换');

    const child = spawn('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', ps1Path],
        { detached: true, stdio: 'ignore', windowsHide: true });
    child.unref();

    setTimeout(() => app.quit(), 400);
    return { ok: true };
}

ipcMain.handle('update:apply', async (event, meta) => {
    try {
        if (!meta || !meta.url) return { ok: false, reason: '缺少下载地址' };

        const dir = path.join(DATA_DIR, 'update');
        try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) { /* ignore */ }
        fs.mkdirSync(dir, { recursive: true });

        const zipPath = path.join(dir, 'app.zip');
        flog('开始下载更新: ' + meta.url);
        const res = await fetch(meta.url);
        if (!res.ok) return { ok: false, reason: '下载失败 HTTP ' + res.status };
        const buf = Buffer.from(await res.arrayBuffer());
        fs.writeFileSync(zipPath, buf);

        if (meta.sha256) {
            const h = crypto.createHash('sha256').update(buf).digest('hex');
            if (h.toLowerCase() !== String(meta.sha256).toLowerCase()) {
                return { ok: false, reason: '校验失败（文件可能损坏）' };
            }
        }
        return await applyZipAndRestart(zipPath);
    } catch (e) {
        flog('update 失败: ' + (e && e.stack ? e.stack : e));
        return { ok: false, reason: (e && e.message) || '未知错误' };
    }
});

// 从本地 zip 更新（作者直接把包发给朋友，不需要任何网站）
ipcMain.handle('update:apply-file', async () => {
    try {
        const r = await dialog.showOpenDialog({
            title: '选择更新包（xbu-x.x.x.zip）',
            filters: [{ name: '更新包', extensions: ['zip'] }],
            properties: ['openFile']
        });
        if (r.canceled || !r.filePaths.length) return { ok: false, reason: 'cancelled' };

        flog('本地更新包: ' + r.filePaths[0]);
        return await applyZipAndRestart(r.filePaths[0]);
    } catch (e) {
        flog('本地更新失败: ' + (e && e.stack ? e.stack : e));
        return { ok: false, reason: (e && e.message) || '未知错误' };
    }
});

ipcMain.handle('updater:open', () => { openUpdaterWindow(); return true; });

ipcMain.handle('schedule:get', () => readSchedule());

ipcMain.handle('schedule:remove', (event, slot, bookHash) => {
    const list = readSchedule().filter(x => !(String(x.slot) === String(slot) && x.bookHash === String(bookHash)));
    writeSchedule(list);
    notifyReminder();
    return list;
});


ipcMain.on('toast:close', () => closeToast());
ipcMain.on('toast:open-reminders', () => {
    closeToast();
    openReminderWindow();
});

ipcMain.handle('reminders:open', () => {
    openReminderWindow();
    return true;
});

ipcMain.handle('accounts:get', () => {
    const a = readAccounts();
    if (!fs.existsSync(ACCOUNTS_FILE)) writeAccounts(a);   // 首次运行就把合并结果落盘
    return a;
});

ipcMain.handle('accounts:add', (event, rawSlot) => {
    const slot = Number(rawSlot);
    const a = readAccounts();
    if (Number.isInteger(slot) && slot > 0 && !a.slots.includes(slot)) {
        a.slots.push(slot);
        a.slots.sort((x, y) => x - y);
    }
    a.last = slot;
    writeAccounts(a);
    flog('accounts:add ' + slot + ' -> ' + JSON.stringify(a));
    return a;
});

ipcMain.handle('accounts:remove', async (event, rawSlot) => {
    const slot = Number(rawSlot);
    const a = readAccounts();
    a.slots = a.slots.filter(s => s !== slot);
    if (!a.slots.length) a.slots = [1];
    if (!a.slots.includes(a.last)) a.last = a.slots[0];
    writeAccounts(a);
    try {
        await session.fromPartition(`persist:fanqie-${slot}`).clearStorageData();
        flog('已清除账号 ' + slot + ' 的登录数据');
    } catch (e) {
        flog('clearStorageData 失败: ' + (e && e.message));
    }
    return a;
});

ipcMain.handle('accounts:set-open-tabs', (event, list) => {
    const a = readAccounts();
    const arr = Array.isArray(list) ? list.filter(n => Number.isInteger(n) && n > 0) : [];
    a.openTabs = Array.from(new Set(arr)).sort((x, y) => x - y);
    writeAccounts(a);
    return a;
});

ipcMain.handle('accounts:set-open', (event, rawSlot, open) => {
    const slot = Number(rawSlot);
    const a = readAccounts();
    const closed = new Set(a.closed || []);
    if (open) closed.delete(slot); else closed.add(slot);
    a.closed = Array.from(closed).sort((x, y) => x - y);
    writeAccounts(a);
    flog('accounts:set-open ' + slot + ' -> ' + (open ? 'open' : 'closed'));
    return a;
});

ipcMain.handle('accounts:rename', (event, rawSlot, rawName) => {
    const slot = Number(rawSlot);
    const a = readAccounts();
    const name = String(rawName || '').trim().slice(0, 20);
    if (!a.names) a.names = {};
    if (name) a.names[slot] = name;
    else delete a.names[slot];
    writeAccounts(a);
    flog('accounts:rename ' + slot + ' -> "' + name + '"');
    return a;
});

ipcMain.on('accounts:set-last', (event, rawSlot) => {
    const slot = Number(rawSlot);
    const a = readAccounts();
    if (a.slots.includes(slot) && a.last !== slot) {
        a.last = slot;
        writeAccounts(a);
    }
});

ipcMain.on('save-file', (event, name, text) => safeWrite(name, text));

// 页面脚本（webview 内）通过 preload 发来的定时诊断
ipcMain.on('save-dump', (event, text) => safeWrite('dump-timed.json', text));

ipcMain.on('toggle-devtools', (event, id) => {
    try {
        const wc = webContents.fromId(Number(id));
        if (!wc) return;
        if (wc.isDevToolsOpened()) wc.closeDevTools();
        else wc.openDevTools({ mode: 'detach' });
    } catch (e) {
        flog('toggle-devtools failed: ' + (e && e.message));
    }
});


/* ---------------- 定时提醒窗口 ---------------- */
function openReminderWindow() {
    if (reminderWin && !reminderWin.isDestroyed()) {
        if (reminderWin.isMinimized()) reminderWin.restore();
        reminderWin.show();
        reminderWin.focus();
        try { reminderWin.webContents.send('schedule:changed'); } catch (e) { /* ignore */ }
        return reminderWin;
    }

    reminderWin = new BrowserWindow({
        width: 460,
        height: 480,
        minWidth: 380,
        minHeight: 280,
        title: '定时发布提醒',
        alwaysOnTop: true,
        autoHideMenuBar: true,
        backgroundColor: '#f7f9fc',
        webPreferences: {
            preload: path.join(__dirname, 'reminder-preload.js'),
            contextIsolation: false,
            nodeIntegration: false
        }
    });

    reminderWin.setMenuBarVisibility(false);
    reminderWin.loadFile(path.join(__dirname, 'reminders.html'));
    reminderWin.webContents.on('did-finish-load', () => {
        try {
            reminderWin.webContents.executeJavaScript('window.__schedPath = ' + JSON.stringify(SCHEDULE_FILE));
        } catch (e) { /* ignore */ }
    });
    reminderWin.on('closed', () => { reminderWin = null; });
    flog('打开定时提醒窗口');
    return reminderWin;
}


/* ---------------- 左上角到期提醒 ---------------- */
const NOTIFIED_FILE = path.join(DATA_DIR, 'notified.json');

function readNotified() {
    try { return JSON.parse(fs.readFileSync(NOTIFIED_FILE, 'utf8')) || {}; } catch (e) { return {}; }
}
function writeNotified(obj) {
    try { fs.writeFileSync(NOTIFIED_FILE, JSON.stringify(obj, null, 2), 'utf8'); } catch (e) { /* ignore */ }
}

function todayKey() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

let toastWin = null;

function closeToast() {
    if (toastWin && !toastWin.isDestroyed()) toastWin.close();
    toastWin = null;
}

function showToast(items, title) {
    closeToast();

    const disp = screen.getPrimaryDisplay();
    const wa = disp.workArea;

    toastWin = new BrowserWindow({
        width: 330,
        height: Math.min(220, 92 + items.length * 22),
        x: wa.x + 16,
        y: wa.y + 16,
        frame: false,
        transparent: true,
        resizable: false,
        movable: true,
        skipTaskbar: true,
        alwaysOnTop: true,
        show: false,
        webPreferences: {
            preload: path.join(__dirname, 'toast-preload.js'),
            contextIsolation: false,
            nodeIntegration: false
        }
    });

    toastWin.setAlwaysOnTop(true, 'screen-saver');
    toastWin.loadFile(path.join(__dirname, 'toast.html'));
    toastWin.once('ready-to-show', () => {
        toastWin.showInactive();
        const acc = readAccounts();
        const payload = {
            title: title,
            items: items.map(it => ({
                bookName: it.bookName || it.bookHash,
                last: it.last,
                days: (typeof it.days === 'number') ? it.days : null,
                account: (acc.names && acc.names[it.slot]) || ('账号 ' + it.slot)
            }))
        };
        try {
            toastWin.webContents.executeJavaScript('renderToast(' + JSON.stringify(payload) + ')');
        } catch (e) { /* ignore */ }
        setTimeout(closeToast, 15000);
    });
    toastWin.on('closed', () => { toastWin = null; });
    flog('弹出到期提醒: ' + items.length + ' 本');
}

// 检查今天是否某本书的最后一个定时发布日
function checkDueReminders() {
    const list = readSchedule();
    if (!list.length) return;

    const today = todayKey();
    const notified = readNotified();
    const due = [];

    for (const it of list) {
        const m = /(\d{4})-(\d{2})-(\d{2})/.exec(it.last || '');
        if (!m) continue;
        const dateKey = m[1] + '-' + m[2] + '-' + m[3];
        if (dateKey !== today) continue;

        const key = it.slot + ':' + it.bookId + ':' + today;
        if (notified[key]) continue;
        due.push(it);
    }

    if (!due.length) return;

    for (const it of due) {
        notified[it.slot + ':' + it.bookId + ':' + today] = Date.now();
    }
    writeNotified(notified);

    showToast(due, due.length > 1 ? `今天有 ${due.length} 本书走到最后一章定时` : '今天是这本书最后的定时发布日');
}

// 启动时：把所有还没到期的书汇总弹一次
function startupSummary() {
    const list = readSchedule();
    if (!list.length) return;

    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const rows = [];

    for (const it of list) {
        const m = /(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2})/.exec(it.last || '');
        if (!m) continue;
        const dt = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5]);
        const days = Math.round((new Date(dt.getFullYear(), dt.getMonth(), dt.getDate()).getTime() - todayStart) / 86400000);
        if (days < 0) continue;
        rows.push({
            bookName: it.bookName || it.bookHash,
            last: it.last,
            slot: it.slot,
            days: days
        });
    }

    if (!rows.length) return;
    rows.sort((a, b) => a.days - b.days);

    const soon = rows.filter(r => r.days <= 3).length;
    const title = rows.length === 1
        ? `《${rows[0].bookName}》还剩 ${rows[0].days} 天到期`
        : `还有 ${rows.length} 本书在定时发布中` + (soon ? `（${soon} 本临近）` : '');

    showToast(rows, title);
}

function startReminderWatcher() {
    setTimeout(() => { try { startupSummary(); } catch (e) { /* ignore */ } }, 4000);
    setInterval(() => { try { checkDueReminders(); } catch (e) { /* ignore */ } }, 30 * 60 * 1000);
}

/* ---------------- 主窗口 ---------------- */
function createWindow() {
    const win = new BrowserWindow({
        width: 1440,
        height: 920,
        minWidth: 960,
        minHeight: 640,
        title: '阿日上传助手',
        backgroundColor: '#f0f2f5',
        autoHideMenuBar: true,
        webPreferences: {
            preload: path.join(__dirname, 'shell-preload.js'),
            webviewTag: true,
            contextIsolation: false,
            nodeIntegration: false,
            spellcheck: false
        }
    });

    win.setMenuBarVisibility(false);
    win.loadFile(path.join(__dirname, 'shell.html'));

    // webview 内的新窗口：站外给系统浏览器，站内就地打开（不再弹第二个窗口）
    win.webContents.on('did-attach-webview', (event, contents) => {
        contents.setWindowOpenHandler(({ url }) => {
            if (!/^https?:/i.test(url)) {
                return { action: 'deny' };
            }
            if (!/fanqienovel\.com/i.test(url)) {
                shell.openExternal(url);
                return { action: 'deny' };
            }
            // 番茄的「新建章节」等用 window.open，这里改为在当前标签页内跳转
            setImmediate(() => {
                try {
                    contents.loadURL(url);
                    flog('站内 popup 就地打开: ' + url);
                } catch (e) {
                    flog('popup 就地打开失败: ' + (e && e.message));
                }
            });
            return { action: 'deny' };
        });
        contents.on('page-title-updated', (e) => e.preventDefault());
        contents.on('render-process-gone', (e, details) => {
            flog('webview render-process-gone: ' + JSON.stringify(details));
        });
    });

    win.on('closed', () => flog('main window closed'));
    return win;
}

/* ---------------- 启动 ---------------- */
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
    app.quit();
} else {
    app.on('second-instance', () => {
        const all = BrowserWindow.getAllWindows();
        if (all.length) {
            const w = all[0];
            if (w.isMinimized()) w.restore();
            w.focus();
        }
    });

    app.whenReady().then(() => {
        // 菜单保持极简，账号切换都在顶部标签页
        Menu.setApplicationMenu(Menu.buildFromTemplate([
            {
                label: '视图',
                submenu: [
                    { label: '放大', role: 'zoomIn' },
                    { label: '缩小', role: 'zoomOut' },
                    { label: '重置缩放', role: 'resetZoom' }
                ]
            }
        ]));
        createWindow();
        startReminderWatcher();
    });

    app.on('window-all-closed', () => app.quit());
}

/* ---------------- 退出前把 Cookie / 存储刷到磁盘 ---------------- */
let quitting = false;
app.on('before-quit', (e) => {
    if (quitting) return;
    quitting = true;
    e.preventDefault();

    try {
        for (const slot of readAccounts().slots) {
            try {
                session.fromPartition(`persist:fanqie-${slot}`).flushStorageData();
            } catch (err) { /* ignore */ }
        }
        flog('退出前已刷新各账号存储');
    } catch (err) {
        flog('flush 失败: ' + (err && err.message));
    }

    setTimeout(() => {
        try { app.quit(); } catch (err) { /* ignore */ }
    }, 800);
});
