const sw = document.getElementById('sw-dark');
let current = { dark: false };

function paint() {
    document.body.classList.toggle('dark', !!current.dark);
    if (sw) sw.classList.toggle('on', !!current.dark);
}

(async function init() {
    try {
        current = await window.settingsApi.get();
    } catch (e) {
        current = { dark: false };
    }
    paint();
})();

if (sw) {
    sw.addEventListener('click', async () => {
        current.dark = !current.dark;
        paint();
        try {
            current = await window.settingsApi.set({ dark: current.dark });
            paint();
        } catch (e) { /* ignore */ }
    });
}