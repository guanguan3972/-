// 定时提醒窗口的预加载
const { ipcRenderer } = require('electron');

window.reminderApi = {
    getSchedule: () => ipcRenderer.invoke('schedule:get'),
    removeSchedule: (slot, bookId) => ipcRenderer.invoke('schedule:remove', slot, bookId),
    renameSchedule: (slot, bookId, name) => ipcRenderer.invoke('schedule:rename', slot, bookId, name),
    getAccounts: () => ipcRenderer.invoke('accounts:get'),
    onChanged: (cb) => ipcRenderer.on('schedule:changed', () => cb())
};
