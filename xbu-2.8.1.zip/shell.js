// 外壳页脚本：标签页 + webview 管理 + 注入
const HOME_URL = 'https://fanqienovel.com/main/writer/';
const WRITER_RE = /fanqienovel\.com\/main\/writer/i;
const PRELOAD_URL = new URL('preload.js', location.href).href;

let AUTOMATION = '';
let SHIM = '';

const views = new Map();      // slot -> webview
const known = new Set();      // 已知账号槽位
let names = {};               // slot -> 自定义名字
let savedOpenTabs = null;      // 上次关软件时开着的标签（null = 从没记录过）
let activeSlot = null;
let tabOrder = [];

const tabsEl = document.getElementById('tabs');
const viewsEl = document.getElementById('views');
const statusEl = document.getElementById('status');
const emptyEl = document.getElementById('empty');
const maskEl = document.getElementById('rename-mask');
const renameInput = document.getElementById('rename-input');
const ctxEl = document.getElementById('ctxmenu');
let renameSlot = null;
let ctxSlot = null;

/* ---------- 右键菜单 ---------- */
function showCtx(slot, x, y) {
    ctxSlot = slot;
    ctxEl.classList.add('show');
    const w = 160;
    const h = 130;
    ctxEl.style.left = Math.min(x, window.innerWidth - w - 8) + 'px';
    ctxEl.style.top = Math.min(y, window.innerHeight - h - 8) + 'px';
}

function escHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function showAccountMenu(x, y) {
    const all = Array.from(known).sort((a, b) => a - b);
    if (!all.length) { setStatus('还没有账号，点「＋ 账号」新建'); return; }

    ctxEl.innerHTML = all.map((s) => {
        const isOpen = views.has(s);
        const label = (names[s] || `账号 ${s}`) + (isOpen ? '（已打开）' : '（已关闭）');
        return `<div class="ctx-item" data-open-slot="${s}" style="${isOpen ? 'color:#94a3b8;' : ''}">${escHtml(label)}</div>`;
    }).join('');

    ctxEl.classList.add('show');
    const w = 190, h = Math.min(320, 40 + all.length * 32);
    ctxEl.style.left = Math.min(x, window.innerWidth - w - 8) + 'px';
    ctxEl.style.top = Math.min(y, window.innerHeight - h - 8) + 'px';

    ctxEl.querySelectorAll('[data-open-slot]').forEach((el) => {
        el.onclick = () => {
            const s = Number(el.dataset.openSlot);
            hideCtx();
            openSlot(s);
        };
    });
}

// 把"当前开着的标签"写回磁盘
function persistOpenTabs() {
    try {
        window.shellApi.setOpenTabs(Array.from(views.keys()).sort((a, b) => a - b));
    } catch (e) { /* ignore */ }
}

function hideCtx() {
    ctxEl.classList.remove('show');
    ctxSlot = null;
}

ctxEl.addEventListener('click', async (ev) => {
    const item = ev.target.closest('.ctx-item');
    if (!item) return;
    const act = item.dataset.act;
    if (!act) return;
    const slot = ctxSlot;
    hideCtx();
    if (slot === null) return;

    if (act === 'rename') {
        openRename(slot);
    } else if (act === 'close') {
        closeSlot(slot);
    } else if (act === 'delete') {
        if (!confirm(`彻底删除「${labelOf(slot)}」？\n\n这会清除该账号的登录数据，无法撤销。`)) return;
        try { await window.shellApi.removeAccount(slot); } catch (e) { /* ignore */ }
        known.delete(slot);
        delete names[slot];
        closeSlot(slot, true);
        setStatus(`${labelOf(slot)} 已删除`);
    }
});

window.addEventListener('click', (ev) => {
    if (!ctxEl.contains(ev.target)) hideCtx();
});
window.addEventListener('blur', hideCtx);

function setStatus(text) {
    statusEl.textContent = text || '';
}

function loadTabOrder() {
    try {
        const raw = localStorage.getItem('tabOrder');
        const arr = raw ? JSON.parse(raw) : [];
        tabOrder = Array.isArray(arr) ? arr.filter(n => Number.isInteger(n)) : [];
    } catch (e) { tabOrder = []; }
}

function saveTabOrder() {
    try { localStorage.setItem('tabOrder', JSON.stringify(tabOrder)); } catch (e) { /* ignore */ }
}

// 按用户拖出来的顺序返回（新账号追加在末尾）
function orderedSlots() {
    const slots = Array.from(views.keys());
    const knownOrder = tabOrder.filter(s => slots.includes(s));
    const rest = slots.filter(s => !knownOrder.includes(s)).sort((a, b) => a - b);
    tabOrder = knownOrder.concat(rest);
    return tabOrder.slice();
}

function moveTab(from, to) {
    if (!from || !to || from === to) return;
    const list = orderedSlots();
    const a = list.indexOf(from);
    const b = list.indexOf(to);
    if (a < 0 || b < 0) return;
    list.splice(a, 1);
    list.splice(b, 0, from);
    tabOrder = list;
    saveTabOrder();
    renderTabs();
}

function labelOf(slot) {
    const n = names[slot];
    return n && String(n).trim() ? String(n).trim() : `账号 ${slot}`;
}

/* ---------- 账号数据 ---------- */
function lsSlots() {
    try {
        const raw = localStorage.getItem('slots');
        const arr = raw ? JSON.parse(raw) : [];
        return Array.isArray(arr) ? arr.filter(n => Number.isInteger(n) && n > 0) : [];
    } catch (e) { return []; }
}

async function loadAccounts() {
    let acc = { slots: [], last: 1, names: {} };
    try {
        acc = await window.shellApi.getAccounts();
    } catch (e) { /* ignore */ }

    const legacy = lsSlots();
    const merged = Array.from(new Set([...(acc.slots || []), ...legacy])).sort((a, b) => a - b);
    if (merged.length === 0) merged.push(1);

    for (const s of merged) {
        if (!(acc.slots || []).includes(s)) {
            try { acc = await window.shellApi.addAccount(s); } catch (e) { /* ignore */ }
        }
    }
    try { localStorage.setItem('slots', JSON.stringify(merged)); } catch (e) { /* ignore */ }

    names = acc.names || {};
    savedOpenTabs = Array.isArray(acc.openTabs) ? acc.openTabs.map(Number) : null;
    const last = Number(acc.last) || merged[0] || 1;
    return { slots: merged, last: merged.includes(last) ? last : merged[0] };
}

/* ---------- 重命名弹层 ---------- */
function openRename(slot) {
    renameSlot = slot;
    renameInput.value = names[slot] || '';
    maskEl.classList.add('show');
    setTimeout(() => { renameInput.focus(); renameInput.select(); }, 30);
}

function closeRename() {
    maskEl.classList.remove('show');
    renameSlot = null;
}

async function commitRename() {
    if (renameSlot === null) return;
    const slot = renameSlot;
    const value = renameInput.value.trim();
    closeRename();
    try {
        const acc = await window.shellApi.renameAccount(slot, value);
        names = acc.names || {};
        renderTabs();
        setStatus(value ? `账号 ${slot} 改名为「${value}」` : `账号 ${slot} 已恢复默认名称`);
    } catch (e) {
        setStatus('改名失败: ' + (e && e.message));
    }
}

document.getElementById('rename-ok').addEventListener('click', commitRename);
document.getElementById('rename-cancel').addEventListener('click', closeRename);
maskEl.addEventListener('click', (ev) => { if (ev.target === maskEl) closeRename(); });
renameInput.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter') { ev.preventDefault(); commitRename(); }
    if (ev.key === 'Escape') { ev.preventDefault(); closeRename(); }
});

/* ---------- 标签页 ---------- */
function renderTabs() {
    tabsEl.innerHTML = '';
    const slots = orderedSlots();

    for (const slot of slots) {
        const tab = document.createElement('div');
        tab.className = 'tab' + (slot === activeSlot ? ' active' : '');
        tab.title = `${labelOf(slot)}  ·  双击改名，右键删除`;
        tab.onclick = () => activate(slot);
        tab.ondblclick = (ev) => { ev.preventDefault(); openRename(slot); };

        const avatar = document.createElement('span');
        avatar.className = 'avatar';
        const name0 = labelOf(slot);
        avatar.textContent = name0.replace(/^账号\s*/, '').slice(0, 1) || String(slot);
        tab.appendChild(avatar);

        const label = document.createElement('span');
        label.className = 'label';
        label.textContent = name0;
        tab.appendChild(label);

        const x = document.createElement('span');
        x.className = 'x';
        x.textContent = '×';
        x.title = '关闭标签（账号保留）';
        x.onclick = (ev) => { ev.stopPropagation(); closeSlot(slot); };
        tab.appendChild(x);

        tab.oncontextmenu = (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            showCtx(slot, ev.clientX, ev.clientY);
        };

        // 拖动排序
        tab.draggable = true;
        tab.addEventListener('dragstart', (e) => {
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', String(slot));
            tab.classList.add('dragging');
        });
        tab.addEventListener('dragend', () => {
            tab.classList.remove('dragging');
            document.querySelectorAll('.tab.drag-over').forEach(el => el.classList.remove('drag-over'));
        });
        tab.addEventListener('dragover', (e) => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            tab.classList.add('drag-over');
        });
        tab.addEventListener('dragleave', () => tab.classList.remove('drag-over'));
        tab.addEventListener('drop', (e) => {
            e.preventDefault();
            tab.classList.remove('drag-over');
            const from = Number(e.dataTransfer.getData('text/plain'));
            moveTab(from, slot);
        });

        tabsEl.appendChild(tab);
    }

    emptyEl.classList.toggle('show', views.size === 0);
}

function activate(slot) {
    activeSlot = slot;
    for (const [s, wv] of views) {
        wv.classList.toggle('active', s === slot);
    }
    renderTabs();
    updateNav();
    try { window.shellApi.setLast(slot); } catch (e) { /* ignore */ }
}

/* ---------- 注入 ---------- */
async function injectInto(wv, slot) {
    // 每次注入都取最新脚本，改完 userscript.js 只要刷新页面
    try {
        const fresh = await window.shellApi.getAutomation();
        if (fresh) {
            AUTOMATION = fresh;
            const m = /@version\s+([\d.]+)/.exec(fresh);
            if (m) setStatus(`脚本 v${m[1]}（${labelOf(slot)}）`);
        }
    } catch (e) { /* 用内存里的旧副本 */ }
    if (!AUTOMATION) return;
    try {
        const guard = `(function () {
            if (window.__novelUploaderBooted) return false;
            window.__novelUploaderBooted = true;
            return true;
        })();`;
        const should = await wv.executeJavaScript(guard);
        if (!should) return;
        await wv.executeJavaScript('window.__novelUploaderSlot = ' + Number(slot) + ';');
        await wv.executeJavaScript(SHIM + '\n' + AUTOMATION);

        // 自检：登记通道是否可用
        try {
            const hasBridge = await wv.executeJavaScript("typeof window.__saveSchedule === 'function'");
            if (!hasBridge) setStatus(`${labelOf(slot)}：登记通道缺失（重启程序）`);
        } catch (e) { /* ignore */ }
        setStatus(`${labelOf(slot)}：脚本已注入`);
    } catch (e) {
        setStatus(`${labelOf(slot)}：注入失败 ${e && e.message}`);
    }
}

/* ---------- 打开 / 关闭 ---------- */
function openSlot(slot, { activateNow = true } = {}) {
    if (views.has(slot)) {
        if (activateNow) activate(slot);
        return views.get(slot);
    }

    const wv = document.createElement('webview');
    wv.setAttribute('partition', `persist:fanqie-${slot}`);
    wv.setAttribute('src', HOME_URL);
    wv.setAttribute('allowpopups', '');
    wv.setAttribute('preload', PRELOAD_URL);
    // 让 guest 的 preload 能直接挂到页面 window 上（双保险）
    wv.setAttribute('webpreferences', 'contextIsolation=no,sandbox=no');
    wv.dataset.slot = String(slot);

    wv.addEventListener('dom-ready', () => setStatus(`${labelOf(slot)}：页面就绪`));

    wv.addEventListener('did-finish-load', () => {
        let url = '';
        try { url = wv.getURL(); } catch (e) { url = ''; }
        if (WRITER_RE.test(url)) injectInto(wv, slot);
        if (/\/publish\//i.test(url)) {
            setTimeout(() => dumpPublishPage(wv, slot), 6000);
        }
        updateNav();
    });

    wv.addEventListener('did-navigate', (ev) => {
        if (WRITER_RE.test(ev.url || '')) injectInto(wv, slot);
        updateNav();
    });

    wv.addEventListener('did-fail-load', (ev) => {
        if (ev.isMainFrame === false) return;
        if (ev.errorCode === -3) return;
        setStatus(`${labelOf(slot)}：加载失败 ${ev.errorDescription || ev.errorCode}`);
        setTimeout(() => { try { wv.loadURL(HOME_URL); } catch (e) { /* ignore */ } }, 3000);
    });

    wv.addEventListener('page-title-updated', (ev) => { ev.preventDefault && ev.preventDefault(); });

    viewsEl.appendChild(wv);
    views.set(slot, wv);
    known.add(slot);

    renderTabs();
    if (activateNow) activate(slot);
    persistOpenTabs();
    return wv;
}

function closeSlot(slot, purge = false) {
    const wv = views.get(slot);
    if (!wv) return;
    try { wv.remove(); } catch (e) { /* ignore */ }
    views.delete(slot);
    if (!purge) known.add(slot);

    persistOpenTabs();

    if (activeSlot === slot) {
        const next = views.keys().next();
        activeSlot = next.done ? null : next.value;
        if (activeSlot) activate(activeSlot); else renderTabs();
    } else {
        renderTabs();
    }
}

function nextSlot() {
    const all = [...known, ...views.keys()];
    return (all.length ? Math.max(...all) : 0) + 1;
}

/* ---------- 发布页留档 ---------- */
async function dumpPublishPage(wv, slot) {
    try {
        const summary = await wv.executeJavaScript(`(function () {
            var els = Array.prototype.slice.call(document.querySelectorAll('input, textarea')).map(function (el, i) {
                var p = el.parentElement ? (el.parentElement.textContent || '') : '';
                return {
                    i: i, tag: el.tagName, type: el.type, placeholder: el.placeholder,
                    value: (el.value || '').slice(0, 60),
                    className: String(el.className).slice(0, 120),
                    id: el.id, name: el.name, maxLength: el.getAttribute('maxlength'),
                    visible: el.offsetParent !== null,
                    parentText: p.replace(/\\s+/g, '').slice(0, 40)
                };
            });
            return JSON.stringify({ url: location.href, inputs: els }, null, 2);
        })()`);
        await window.shellApi.saveFile('dump-inputs.json', summary);
        const html = await wv.executeJavaScript('document.documentElement.outerHTML');
        await window.shellApi.saveFile('dump-publish.html', String(html).slice(0, 3000000));
        setStatus(`${labelOf(slot)}：发布页结构已留档`);
    } catch (e) {
        setStatus(`留档失败 ${e && e.message}`);
    }
}

/* ---------- 快捷键 ---------- */
window.addEventListener('keydown', (ev) => {
    if (ev.key === 'Escape') {
        hideCtx();
        if (maskshow()) closeRename();
        return;
    }
    if (maskshow()) return;
    if (ev.ctrlKey && (ev.key === 't' || ev.key === 'T')) {
        ev.preventDefault();
        const slot = nextSlot();
        window.shellApi.addAccount(slot).then(() => openSlot(slot));
        return;
    }
    if (ev.altKey && ev.key === 'ArrowLeft') {
        ev.preventDefault();
        withActiveView(wv => wv.canGoBack() && wv.goBack());
        return;
    }
    if (ev.altKey && ev.key === 'ArrowRight') {
        ev.preventDefault();
        withActiveView(wv => wv.canGoForward() && wv.goForward());
        return;
    }
    if (ev.ctrlKey && /^[1-9]$/.test(ev.key)) {
        ev.preventDefault();
        const slot = Number(ev.key);
        if (known.has(slot) || views.has(slot)) openSlot(slot);
        return;
    }
    const wv = activeSlot ? views.get(activeSlot) : null;
    if (!wv) return;
    if (ev.key === 'F5') {
        ev.preventDefault();
        try { wv.reload(); } catch (e) { /* ignore */ }
    }
    if (ev.key === 'F12' || (ev.ctrlKey && ev.shiftKey && (ev.key === 'i' || ev.key === 'I'))) {
        ev.preventDefault();
        window.shellApi.toggleDevTools(wv.getWebContentsId());
    }
});

function maskshow() {
    return maskEl.classList.contains('show');
}

/* ---------- 左上角鲸鱼：唤回上传面板 ---------- */
document.getElementById('brand').addEventListener('click', async () => {
    const wv = activeSlot ? views.get(activeSlot) : null;
    if (!wv) {
        setStatus('还没有打开账号');
        return;
    }
    const ask = `(function () {
        if (typeof window.__novelUploaderShowPanel === 'function') {
            window.__novelUploaderShowPanel();
            return true;
        }
        return false;
    })();`;
    try {
        let ok = await wv.executeJavaScript(ask);
        if (!ok) {
            // 当前页面还没注入脚本（比如登录页）—— 立刻注入一次再唤回
            setStatus('正在载入脚本…');
            await injectInto(wv, activeSlot);
            await new Promise(r => setTimeout(r, 800));
            ok = await wv.executeJavaScript(ask);
        }
        setStatus(ok ? `${labelOf(activeSlot)}：面板已唤回` : '当前页面不支持面板，请先进入章节管理页');
    } catch (e) {
        setStatus('唤回失败: ' + (e && e.message));
    }
});
/* ---------- 导航按钮 ---------- */
function activeView() {
    return activeSlot ? views.get(activeSlot) : null;
}

function updateAddress() {
    const el = document.getElementById('addr-text');
    if (!el) return;
    const wv = activeView();
    let text = '—';
    if (wv) {
        try {
            const url = wv.getURL() || '';
            if (url) {
                text = url.replace(/^https?:\/\//, '');
                if (text.length > 78) text = text.slice(0, 76) + '…';
            }
        } catch (e) { /* ignore */ }
    }
    el.textContent = text;
}

function updateNav() {
    const wv = activeView();
    const back = document.getElementById('nav-back');
    const fwd = document.getElementById('nav-forward');
    let canB = false, canF = false;
    try {
        if (wv) { canB = !!wv.canGoBack(); canF = !!wv.canGoForward(); }
    } catch (e) { /* ignore */ }
    if (back) back.disabled = !canB;
    if (fwd) fwd.disabled = !canF;
    updateAddress();
}

function withActiveView(fn) {
    const wv = activeView();
    if (!wv) { setStatus('还没有打开账号'); return; }
    try { fn(wv); } catch (e) { setStatus('操作失败: ' + (e && e.message)); }
    updateNav();
}

document.getElementById('nav-back').addEventListener('click', () => withActiveView(wv => wv.canGoBack() && wv.goBack()));
document.getElementById('nav-forward').addEventListener('click', () => withActiveView(wv => wv.canGoForward() && wv.goForward()));
document.getElementById('nav-reload').addEventListener('click', () => withActiveView(wv => wv.reload()));
document.getElementById('nav-home').addEventListener('click', () => withActiveView(wv => wv.loadURL(HOME_URL)));

document.getElementById('update').addEventListener('click', async () => {
    try {
        await window.shellApi.openUpdater();
    } catch (e) {
        setStatus('打开更新失败: ' + (e && e.message));
    }
});

document.getElementById('alarm').addEventListener('click', async () => {
    try {
        await window.shellApi.openReminders();
    } catch (e) {
        setStatus('打开提醒失败: ' + (e && e.message));
    }
});

document.getElementById('accounts-menu').addEventListener('click', (ev) => {
    ev.stopPropagation();
    const r = ev.currentTarget.getBoundingClientRect();
    showAccountMenu(r.left, r.bottom + 6);
});

document.getElementById('add').addEventListener('click', async () => {
    const slot = nextSlot();
    try { await window.shellApi.addAccount(slot); } catch (e) { /* ignore */ }
    openSlot(slot);
    setStatus(`已新增账号 ${slot}，请登录（双击标签可改名）`);
});

/* ---------- 启动 ---------- */
(async function boot() {
    try {
        AUTOMATION = await window.shellApi.getAutomation();
        SHIM = `;(function () {
            if (window.__novelUploaderGMReady) return;
            window.__novelUploaderGMReady = true;
            window.GM_addStyle = function (css) {
                var s = document.createElement('style');
                s.textContent = css;
                (document.head || document.documentElement).appendChild(s);
                return s;
            };
            window.GM_setValue = function (k, v) { try { localStorage.setItem('gm:' + k, JSON.stringify(v)); } catch (e) {} };
            window.GM_getValue = function (k, d) {
                try { var v = localStorage.getItem('gm:' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; }
            };
            window.GM_deleteValue = function (k) { try { localStorage.removeItem('gm:' + k); } catch (e) {} };
            window.GM_setClipboard = function (text) {
                try {
                    var ta = document.createElement('textarea');
                    ta.value = text;
                    ta.style.cssText = 'position:fixed;left:-9999px;top:0;';
                    document.body.appendChild(ta);
                    ta.select();
                    document.execCommand('copy');
                    ta.remove();
                } catch (e) {}
            };
        })();`;
    } catch (e) {
        setStatus('脚本加载失败: ' + (e && e.message));
        return;
    }

    loadTabOrder();

    const acc = await loadAccounts();
    for (const s of acc.slots) known.add(s);

    const order = acc.slots.slice().sort((a, b) => a - b);
    // 有快照就严格照快照恢复；没有快照（首次/老版本）才全部打开
    const toOpen = (savedOpenTabs === null) ? order : order.filter(s => savedOpenTabs.includes(s));

    if (toOpen.length === 0) {
        renderTabs();
        setStatus(order.length
            ? `上次关闭时没有开着的账号（共 ${order.length} 个，点 ＋账号 右侧 ▾ 可打开）`
            : '还没有账号，点「＋ 账号」开始');
        return;
    }

    const last = toOpen.includes(Number(acc.last)) ? Number(acc.last) : toOpen[0];

    for (const s of toOpen) openSlot(s, { activateNow: false });
    if (last) activate(last);

    const hidden = order.length - toOpen.length;
    setStatus(`已恢复 ${toOpen.length} 个账号` + (hidden ? `（另有 ${hidden} 个上次就关着）` : ''));
})();
