// 外壳页预加载：暴露给 shell.js 的能力
const { ipcRenderer } = require('electron');

window.shellApi = {
    getAutomation: () => ipcRenderer.invoke('get-automation'),
    saveFile: (name, text) => ipcRenderer.send('save-file', String(name), String(text)),
    toggleDevTools: (id) => ipcRenderer.send('toggle-devtools', Number(id)),

    getAccounts: () => ipcRenderer.invoke('accounts:get'),
    addAccount: (slot) => ipcRenderer.invoke('accounts:add', Number(slot)),
    removeAccount: (slot) => ipcRenderer.invoke('accounts:remove', Number(slot)),
    renameAccount: (slot, name) => ipcRenderer.invoke('accounts:rename', Number(slot), String(name || '')),
    setLast: (slot) => ipcRenderer.send('accounts:set-last', Number(slot)),
    setOpen: (slot, open) => ipcRenderer.invoke('accounts:set-open', Number(slot), !!open),
    setOpenTabs: (list) => ipcRenderer.invoke('accounts:set-open-tabs', list),

    openReminders: () => ipcRenderer.invoke('reminders:open'),
    openUpdater: () => ipcRenderer.invoke('updater:open'),
    openHome: () => ipcRenderer.invoke('splash:open')
};
