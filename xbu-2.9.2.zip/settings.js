const sw = document.getElementById('sw-dark');
let current = { dark: false };

function paint() {
    document.body.classList.toggle('dark', !!current.dark);
    if (sw) sw.classList.toggle('on', !!current.dark);
}

(async function init() {
    try {
        current = await window.settingsApi.get();
    } catch (e) {
        current = { dark: false };
    }
    paint();
})();

if (sw) {
    sw.addEventListener('click', async () => {
        current.dark = !current.dark;
        paint();
        try {
            current = await window.settingsApi.set({ dark: current.dark });
            paint();
        } catch (e) { /* ignore */ }
    });
}

// 复制微信号
var copyBtn = document.getElementById('copy-contact');
if (copyBtn) {
    copyBtn.addEventListener('click', function () {
        var txt = 'guanguan52867';
        try { navigator.clipboard.writeText(txt); } catch (e) { /* ignore */ }
        copyBtn.textContent = '已复制';
        setTimeout(function () { copyBtn.textContent = '复制微信号'; }, 1500);
    });
}
